# Truck Life v1.25 — Exportação e notificações Android

## Exportação de dados
O Perfil inclui **Exportar cópia dos meus dados**. A app reúne dados pessoais locais relevantes (Diário, CMR/documentos, viagens/visitas, perfil, veículos, alertas, preferências e outros registos `tl_` / `trucklife_`) num backup JSON.

São excluídos estados técnicos que não devem ser tratados como dados de utilizador exportáveis/restauráveis, incluindo cache OSM, última coordenada GPS, fila/meta de sync, autenticação local e estado técnico de billing/entitlement.

No Android, o utilizador escolhe onde guardar o ficheiro através do seletor de documentos. A exportação não é uma função Premium de escrita e continua disponível quando o trial/subscrição expira.

## Alertas locais Android
Os alertas de veículo/documentos guardados em `tl_vehicle_alerts_v1` usam os offsets configurados no registo (por exemplo 30, 15, 7 e 1 dia antes).

A interface envia ao shell Android uma lista normalizada de lembretes futuros. O Android usa `AlarmManager.setAndAllowWhileIdle`, suficiente para avisos de validade em que precisão ao minuto não é necessária.

- Android 13+: pede `POST_NOTIFICATIONS` quando o utilizador ativa notificações.
- A agenda nativa é substituída quando alertas são criados, editados, renovados ou eliminados.
- A agenda fica em `SharedPreferences` e é reconstruída em `BOOT_COMPLETED` / `MY_PACKAGE_REPLACED`.
- Se a preferência **Validades do veículo** for desligada, a lista nativa é limpa.

## Limites atuais
Isto implementa lembretes **locais** do próprio telemóvel. Push remoto para respostas da Comunidade, mensagens ou eventos do servidor dependerá de Firebase Cloud Messaging/backend quando o Firebase for ligado.
