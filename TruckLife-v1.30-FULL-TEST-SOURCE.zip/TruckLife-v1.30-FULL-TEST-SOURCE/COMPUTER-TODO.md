# Truck Life — bloco reservado para quando houver computador

1. Android Studio/SDK + abrir a MASTER.
2. Criar e guardar keystore permanente.
3. Compilar APK de teste com package de teste e validar assinatura.
4. Firebase project + app Android + SHA + google-services.json.
5. Google Sign-In real e conta do proprietário marcada como ADMIN no servidor.
6. Firestore/backend + regras por UID + App Check/anti-abuso equivalente ao canal de distribuição escolhido.
7. Ligar painel Admin ao backend.
8. Configurar fornecedor(es) de pagamento e webhooks; testar sandbox.
9. Testes de segurança reais: acesso cruzado, admin falso, Premium falso, trial manipulado, replay de pagamentos, uploads e rate limiting.
10. GPS/navegação HGV e análise dos ficheiros iGO fornecidos pelo utilizador.
11. Testes finais em dispositivo, atualização/migração e distribuição via site/Play Store conforme decisão final.
