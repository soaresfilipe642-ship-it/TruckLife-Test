# Truck Life v1.22 — Conta Google e Cloud

## O que já está no projeto
- `auth.js`: estado de autenticação e ponte preparada para o login Google nativo.
- `account.html`: ecrã de conta Google e estado da sincronização.
- `cloud_sync.js`: camada offline-first que observa alterações dos dados principais e cria uma fila pequena de sincronização.
- A fila guarda apenas **que chave mudou**, não duplica fotografias/base64 dentro da fila.
- Quando houver internet e uma conta Google/backend configurados, `flush()` envia as alterações pelo transporte nativo.
- Os dados continuam a ser gravados localmente primeiro, portanto a app continua utilizável sem internet.

## Dados cobertos pela primeira sincronização
- perfil e definições;
- veículo e alertas;
- Diário e tarifa por km;
- CMR/documentos;
- Minha Viagem e visitas;
- locais favoritos.

Caches de mapa/GPS e estados de demonstração não entram na cloud.

## Produção — configuração externa ainda necessária
A autenticação Google real não pode ser ativada apenas com código-fonte genérico. O projeto precisa de:
1. Projeto Firebase/Google associado ao package `com.trucklife.prototype`.
2. SHA-1/SHA-256 da chave de assinatura definitiva.
3. Google como fornecedor de autenticação ativado.
4. `google-services.json`/OAuth Web Client ID do projeto.
5. Firestore (ou outro backend) e Storage para fotografias/documentos.
6. Regras de segurança: cada utilizador só lê/escreve os próprios dados; dados comunitários têm regras próprias.

## Modelo inicial de backend
- `users/{uid}` — perfil, idioma, createdAt, lastSeenAt.
- `entitlements/{uid}` — estado do trial/subscrição, trialStartedAt, trialEndsAt, subscriptionEndsAt, provider, updatedAt.
- `userData/{uid}/kv/{key}` — ponte de migração para os dados locais existentes, com value/version/updatedAt/deleted.
- `users/{uid}/documents/{documentId}` — metadados CMR/documentos.
- ficheiros/fotografias em Cloud Storage, nunca como payload gigante de Firestore.
- `community/*` — coleção separada e moderada.

A ponte `kv` permite pôr a versão atual na cloud sem reescrever todos os ecrãs de uma vez. Mais tarde os módulos podem ser normalizados em coleções próprias.

## Trial seguro
O cliente pode mostrar o prazo, mas a autoridade deve ser o servidor. O servidor cria o trial no primeiro login Google e devolve o estado de entitlement. Alterar a data/hora do telemóvel não deve prolongar o acesso.
