# Truck Life v1.29 — Bluetooth / Tacógrafo

A camada Android implementa agora:

- permissões Bluetooth modernas (Android 12+);
- pesquisa BLE de VDO DTCO / Stoneridge SE5000 e dispositivos que anunciem o serviço ITS normalizado;
- emparelhamento/bonding com confirmação de PIN/token no tacógrafo e telemóvel;
- ligação GATT;
- deteção dos serviços normalizados Smart Tachograph v2;
- ativação de indications e canal de créditos para o transporte ITS;
- callbacks para a WebView e estado real na página `tacho.html`;
- hook para envio de pacotes do protocolo de download.

UUIDs implementados segundo a especificação Smart Tachograph v2 VU / Transport protocol for ITS:

- Download service: `eef90782-55dd-4388-b80b-695aba7a69b5`
- Download FIFO: `29d3a479-1592-47df-80a4-afa742d369bb`
- Download credits: `db9c4128-bff3-41fe-a306-fb6f9a8aeb2d`
- Diagnostics service: `fa213def-aef4-475c-bcea-0a8d69073efc`
- Diagnostics FIFO: `e413960c-75ba-4ca9-8a67-99bc052a1b13`
- Diagnostics credits: `e168d1a6-304f-42b4-ab96-4cd1d4efebd9`

## Limite desta etapa

A ligação Bluetooth/ITS é real. A leitura e interpretação da jornada ainda não deve ser apresentada como real até implementarmos e validarmos, em hardware, os comandos de download/diagnóstico definidos nos protocolos do tacógrafo. O modo demo continua separado e claramente identificado.
