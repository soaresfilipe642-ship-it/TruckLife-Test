'use strict';
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const js=fs.readFileSync(path.join(root,'admin-web/admin.js'),'utf8');
const html=fs.readFileSync(path.join(root,'admin-web/index.html'),'utf8');
const profile=fs.readFileSync(path.join(root,'app/src/main/assets/profile.html'),'utf8');
const failures=[];
const ok=(cond,msg)=>{if(!cond)failures.push(msg)};
ok(!/localStorage\.setItem|sessionStorage\.setItem/.test(js),'admin token/session must not be persisted in Web Storage');
ok(!/\.innerHTML\s*=/.test(js),'admin dynamic UI must not use innerHTML');
ok(js.includes("Authorization','Bearer '"),'admin requests must carry bearer token');
ok(js.includes("credentials:'omit'"),'admin fetch must not silently depend on ambient cookies');
ok(js.includes("cache:'no-store'"),'admin API requests must avoid browser cache');
ok(html.includes('Content-Security-Policy'),'admin prototype must include CSP baseline');
ok(!profile.includes('admin.html'),'public driver profile must not link to embedded admin panel');
ok(!fs.existsSync(path.join(root,'app/src/main/assets/admin.html')),'admin.html must not ship in driver APK');
ok(!fs.existsSync(path.join(root,'app/src/main/assets/admin.js')),'admin.js must not ship in driver APK');
if(failures.length){console.error('FAIL admin security');failures.forEach(x=>console.error('-',x));process.exit(1)}
console.log('PASS admin security boundary: separate panel, in-memory auth, bearer API, no embedded admin UI.');
