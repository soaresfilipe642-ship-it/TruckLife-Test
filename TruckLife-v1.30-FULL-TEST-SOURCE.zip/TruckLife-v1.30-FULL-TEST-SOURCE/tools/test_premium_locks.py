from pathlib import Path
root=Path(__file__).resolve().parents[1]/"app/src/main/assets"
required={
"diary.html":["access.js","premium('guardar ou alterar dias do Diário')","premium('adicionar atividades ao Diário')"],
"cmr.html":["access.js","premium('guardar ou alterar CMR e documentos')","premium('editar CMR e documentos')"],
"trip.html":["access.js","premium('registar estados da visita')","premium('guardar visitas e Diário')"],
"vehicle.html":["access.js","premium('guardar ou alterar veículos')","premium('guardar ou alterar alertas')"],
"community.html":["access.js","premium('participar na Comunidade')","premium('votar na Comunidade')"],
"ai.html":["access.js","premium('usar o Assistente IA')"]}
problems=[]
for fn,needles in required.items():
    text=(root/fn).read_text(encoding="utf-8")
    for n in needles:
        if n not in text: problems.append(f"{fn}: missing {n}")
if problems:
    print("FAIL premium policy")
    [print("-",x) for x in problems]
    raise SystemExit(1)
print("PASS premium/read-only gates present on all target modules")
