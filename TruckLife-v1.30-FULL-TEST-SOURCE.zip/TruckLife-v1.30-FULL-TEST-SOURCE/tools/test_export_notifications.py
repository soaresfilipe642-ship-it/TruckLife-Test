from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/trucklife/prototype/MainActivity.java').read_text()
vehicle=(root/'app/src/main/assets/vehicle.html').read_text()
profile=(root/'app/src/main/assets/profile.html').read_text()
manifest=root/'app/src/main/AndroidManifest.xml'
ET.parse(manifest)
checks={
 'export bridge':'exportUserData(String json)' in main,
 'notification permission bridge':'requestNotificationPermission()' in main,
 'reminder replacement bridge':'replaceAlertReminders(String json)' in main,
 'notification permission manifest':'android.permission.POST_NOTIFICATIONS' in manifest.read_text(),
 'boot receiver manifest':'.BootReceiver' in manifest.read_text(),
 'notification receiver manifest':'.NotificationReceiver' in manifest.read_text(),
 'profile export button':'exportMyData()' in profile and 'Exportar cópia dos meus dados' in profile,
 'profile export allowed independent of premium':'function exportMyData()' in profile and "premium('export" not in profile,
 'vehicle schedules native reminders':'buildNativeReminders()' in vehicle and 'replaceAlertReminders' in vehicle,
 'vehicle notification opt-in':'enableAndroidNotifications()' in vehicle,
 'scheduler source':(root/'app/src/main/java/com/trucklife/prototype/AlertReminderScheduler.java').exists(),
 'receiver source':(root/'app/src/main/java/com/trucklife/prototype/NotificationReceiver.java').exists(),
}
failed=[k for k,v in checks.items() if not v]
if failed:
 print('FAIL:', ', '.join(failed)); raise SystemExit(1)
print('PASS export/notification source checks:', len(checks))
