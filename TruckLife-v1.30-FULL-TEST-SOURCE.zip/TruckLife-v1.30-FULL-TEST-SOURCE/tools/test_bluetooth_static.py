from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=(root/'app/src/main/java/com/trucklife/prototype/TachographBluetoothManager.java').read_text()
main=(root/'app/src/main/java/com/trucklife/prototype/MainActivity.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
tacho=(root/'app/src/main/assets/tacho.html').read_text()
checks={
 'scan permission':'BLUETOOTH_SCAN' in manifest and 'BLUETOOTH_CONNECT' in manifest,
 'download service uuid':'eef90782-55dd-4388-b80b-695aba7a69b5' in java,
 'download fifo uuid':'29d3a479-1592-47df-80a4-afa742d369bb' in java,
 'credits uuid':'db9c4128-bff3-41fe-a306-fb6f9a8aeb2d' in java,
 'gatt connect':'connectGatt' in java,
 'bonding':'createBond' in java,
 'bridge scan':'startTachographScan' in main,
 'bridge connect':'connectTachograph' in main,
 'web callback':'truckLifeBluetoothEvent' in tacho,
 'no fake real import':'Protocolo de jornada/ficheiro' in tacho and 'Em validação' in tacho,
}
for k,v in checks.items():
    if not v: raise SystemExit('FAIL '+k)
print('PASS bluetooth static integration',len(checks),'checks')
