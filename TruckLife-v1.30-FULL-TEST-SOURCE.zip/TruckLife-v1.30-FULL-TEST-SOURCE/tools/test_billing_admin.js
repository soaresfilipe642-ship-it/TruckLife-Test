const fs=require('fs'),vm=require('vm');
class Storage{constructor(){this.m=new Map()}getItem(k){return this.m.has(k)?this.m.get(k):null}setItem(k,v){this.m.set(String(k),String(v))}removeItem(k){this.m.delete(String(k))}}
const calls=[];const localStorage=new Storage(),document={addEventListener(){},querySelectorAll(){return []},getElementById(){return null}},window={localStorage,TruckLifeNative:{isBillingConfigured(){return true},startCheckout(provider,productId){calls.push({provider,productId});return true},openManageSubscription(){}},dispatchEvent(){},addEventListener(){}};
class CustomEvent{constructor(type,init){this.type=type;this.detail=init?.detail}}
const ctx={console,Storage,localStorage,document,window,CustomEvent,location:{href:''},alert(){},Date,JSON,Math,setTimeout,clearTimeout};window.window=window;ctx.globalThis=ctx;
for(const f of ['auth.js','access.js','billing.js']){vm.runInNewContext(fs.readFileSync(__dirname+'/../app/src/main/assets/'+f,'utf8'),ctx,{filename:f});ctx.TL_AUTH=window.TL_AUTH;ctx.TL_ACCESS=window.TL_ACCESS;ctx.TL_BILLING=window.TL_BILLING}
function ok(c,m){if(!c)throw new Error(m)}
ctx.TL_AUTH.acceptGoogleResult({uid:'user1',email:'driver@example.com'});ok(ctx.TL_AUTH.isSignedIn(),'signed in user accepted');
ok(ctx.TL_BILLING.PRODUCT_LIST.length===3,'three subscription plans');
ok(ctx.TL_BILLING.byId('trucklife_monthly_5_eur').priceEur===5,'monthly is 5 EUR');
ok(ctx.TL_BILLING.byId('trucklife_6month_9_eur').priceEur===9,'six months is 9 EUR');
ok(ctx.TL_BILLING.byId('trucklife_annual_12_eur').priceEur===12,'annual is 12 EUR');
let r=ctx.TL_BILLING.startCheckout('GOOGLE_PLAY','trucklife_6month_9_eur');ok(r.ok,'checkout starts');ok(calls[0].productId==='trucklife_6month_9_eur','selected product reaches native layer');
const n=Date.now();r=ctx.TL_BILLING.applyPurchaseResult({status:'VERIFIED',provider:'GOOGLE_PLAY',productId:'trucklife_6month_9_eur',receiptId:'r1',entitlement:{state:'ACTIVE',serverNow:n,subscriptionEndsAt:n+183*86400000,provider:'GOOGLE_PLAY'}});ok(r.ok,'verified payment applied');ok(ctx.TL_ACCESS.get().state==='ACTIVE','active entitlement after verified payment');
console.log('PASS billing plans + entitlement smoke test');
