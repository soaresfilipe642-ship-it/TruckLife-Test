from pathlib import Path
from bs4 import BeautifulSoup
import subprocess, sys, tempfile

root = Path(__file__).resolve().parents[1]
assets = root / 'app' / 'src' / 'main' / 'assets'
problems=[]
checked=[]

for html in sorted(assets.glob('*.html')):
    text=html.read_text(encoding='utf-8')
    soup=BeautifulSoup(text,'html.parser')
    checked.append(html.name)
    for tag,attr in [('a','href'),('script','src'),('link','href'),('img','src')]:
        for el in soup.find_all(tag):
            v=el.get(attr)
            if not v or v.startswith(('http:','https:','#','data:','javascript:','mailto:','tel:')):
                continue
            base=v.split('#')[0].split('?')[0]
            if base and '${' not in base and not (assets/base).exists():
                problems.append(f'{html.name}: missing local reference {v}')
    ids=[x.get('id') for x in soup.find_all(attrs={'id':True})]
    for item in sorted({x for x in ids if ids.count(x)>1}):
        problems.append(f'{html.name}: duplicate id {item}')
    for i,sc in enumerate(soup.find_all('script')):
        if sc.get('src'):
            continue
        code=sc.string or sc.get_text() or ''
        if not code.strip():
            continue
        with tempfile.NamedTemporaryFile('w',suffix='.js',delete=False,encoding='utf-8') as f:
            f.write(code); tmp=f.name
        p=subprocess.run(['node','--check',tmp],capture_output=True,text=True)
        if p.returncode:
            problems.append(f'{html.name}: inline JS #{i}: {p.stderr.strip()}')

for js in sorted(assets.glob('*.js')):
    p=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
    if p.returncode:
        problems.append(f'{js.name}: {p.stderr.strip()}')

print(f'Checked {len(checked)} HTML screens: {", ".join(checked)}')
if problems:
    print(f'FAIL: {len(problems)} problem(s)')
    for problem in problems: print('-',problem)
    sys.exit(1)
print('PASS: no missing local references, duplicate HTML ids, or JavaScript syntax errors detected.')
