const fs=require('fs'),vm=require('vm');
class Storage{constructor(){this.m=new Map()}getItem(k){return this.m.has(k)?this.m.get(k):null}setItem(k,v){this.m.set(String(k),String(v))}removeItem(k){this.m.delete(String(k))}}
const localStorage=new Storage(),document={addEventListener(){},querySelectorAll(){return []}},window={localStorage,TruckLifeNative:{isGoogleAuthConfigured(){return false},isCloudSyncConfigured(){return false}},dispatchEvent(){},addEventListener(){}};
class CustomEvent{constructor(type,init){this.type=type;this.detail=init?.detail}}
const ctx={console,Storage,localStorage,document,window,CustomEvent,location:{href:''},alert(){},setTimeout,clearTimeout,Date,JSON,Math};window.window=window;ctx.globalThis=ctx;
for(const f of ['auth.js','cloud_sync.js','access.js']){vm.runInNewContext(fs.readFileSync(__dirname+'/../app/src/main/assets/'+f,'utf8'),ctx,{filename:f});ctx.TL_AUTH=window.TL_AUTH;ctx.TL_SYNC=window.TL_SYNC;ctx.TL_ACCESS=window.TL_ACCESS}
function ok(c,m){if(!c)throw new Error(m)}
ok(!ctx.TL_AUTH.isSignedIn(),'starts signed out');
localStorage.setItem('tl_profile_v1',JSON.stringify({name:'Driver'}));ok(ctx.TL_SYNC.pendingCount()===1,'user data queued');
localStorage.setItem('trucklife_osm_pois_v120','cache');ok(ctx.TL_SYNC.pendingCount()===1,'map cache excluded');
ctx.TL_AUTH.acceptGoogleResult({uid:'test-user',email:'driver@example.com'});ok(ctx.TL_AUTH.uid()==='test-user','Google account attached');
let e=ctx.TL_ACCESS.get();ok(e.state==='TRIAL','trial state available');
const n=Date.now();ctx.TL_ACCESS.applyServerEntitlement({state:'ACTIVE',serverNow:n,subscriptionEndsAt:n+3*86400000,provider:'test'});e=ctx.TL_ACCESS.get();ok(e.state==='ACTIVE','server entitlement applied');ok(ctx.TL_ACCESS.daysLeft(e)===3,'server expiry used');
console.log('PASS account/cloud/trial smoke test');
