from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
issues=[]

def add(sev,msg,path=''):
    issues.append((sev,msg,path))

manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(errors='ignore')
main=(ROOT/'app/src/main/java/com/trucklife/prototype/MainActivity.java').read_text(errors='ignore')
auth=(ROOT/'app/src/main/assets/auth.js').read_text(errors='ignore')
admin_web=(ROOT/'admin-web/admin.js').read_text(errors='ignore') if (ROOT/'admin-web/admin.js').exists() else ''
admin_html=(ROOT/'admin-web/index.html').read_text(errors='ignore') if (ROOT/'admin-web/index.html').exists() else ''

if 'android:allowBackup="true"' in manifest: add('HIGH','Android backup is enabled','AndroidManifest.xml')
if 'android:usesCleartextTraffic="false"' not in manifest: add('HIGH','Cleartext traffic is not explicitly disabled','AndroidManifest.xml')
if 'isAdminVerified' in auth or 'admin.html' in (ROOT/'app/src/main/assets/profile.html').read_text(errors='ignore'):
    add('HIGH','Public APK still contains an embedded admin authorization path','app assets')
if (ROOT/'app/src/main/assets/admin.html').exists() or (ROOT/'app/src/main/assets/admin.js').exists():
    add('HIGH','Admin UI is still bundled inside the public APK','app assets')
if 'setWebContentsDebuggingEnabled(false)' not in main: add('MEDIUM','WebView debugging not explicitly disabled','MainActivity.java')
if 'MIXED_CONTENT_NEVER_ALLOW' not in main: add('MEDIUM','WebView mixed content not explicitly denied','MainActivity.java')
if 'localStorage.setItem' in admin_web or 'sessionStorage.setItem' in admin_web:
    add('HIGH','Admin browser persists session/token in Web Storage','admin-web/admin.js')
if '.innerHTML' in admin_web:
    add('HIGH','Admin UI uses innerHTML for dynamic content','admin-web/admin.js')
if "Authorization','Bearer '" not in admin_web:
    add('HIGH','Admin API requests do not attach bearer token','admin-web/admin.js')
if "Content-Security-Policy" not in admin_html:
    add('MEDIUM','Admin web prototype has no CSP baseline','admin-web/index.html')

# Firebase baseline checks.
fr=(ROOT/'backend/firebase/firestore.rules').read_text(errors='ignore') if (ROOT/'backend/firebase/firestore.rules').exists() else ''
sr=(ROOT/'backend/firebase/storage.rules').read_text(errors='ignore') if (ROOT/'backend/firebase/storage.rules').exists() else ''
if 'match /{document=**}' not in fr or 'allow read, write: if false;' not in fr:
    add('HIGH','Firestore rules lack explicit deny-by-default fallback','backend/firebase/firestore.rules')
if 'match /{allPaths=**}' not in sr or 'allow read, write: if false;' not in sr:
    add('HIGH','Storage rules lack explicit deny-by-default fallback','backend/firebase/storage.rules')
if 'match /entitlements/{uid}' not in fr or 'allow write: if false;' not in fr:
    add('HIGH','Client may be able to write entitlements','backend/firebase/firestore.rules')

# Secret scan, excluding docs/examples and scanner itself.
secret_re=re.compile(r'(?i)(client_secret|private[_-]?key|api[_-]?secret|service[_-]?account|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----)')
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix.lower() in {'.jpg','.png','.zip','.apk'} or p.name in {'security_audit.py'}: continue
    if p.suffix.lower() not in {'.java','.kt','.kts','.js','.json','.xml','.properties','.rules'}: continue
    txt=p.read_text(errors='ignore')
    if secret_re.search(txt): add('CRITICAL','Possible embedded secret/private key',str(p.relative_to(ROOT)))

order={'CRITICAL':0,'HIGH':1,'MEDIUM':2,'LOW':3}
issues.sort(key=lambda x: order[x[0]])
print('Truck Life security static audit v1.27')
if not issues:
    print('PASS: no findings covered by this scanner')
    sys.exit(0)
for sev,msg,path in issues:
    print(f'{sev}: {msg} [{path}]')
sys.exit(2 if any(s in {'CRITICAL','HIGH'} for s,_,_ in issues) else 0)
