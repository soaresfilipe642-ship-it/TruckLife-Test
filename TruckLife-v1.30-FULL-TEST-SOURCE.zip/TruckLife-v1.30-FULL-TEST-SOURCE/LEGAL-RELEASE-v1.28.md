# Truck Life — privacidade, termos e avisos

A v1.28 inclui páginas locais de rascunho `privacy.html` e `terms.html`, acessíveis a partir do Perfil.

Antes de publicar, completar:
1. identidade/contacto do responsável pelo serviço;
2. fornecedores reais de cloud, autenticação e pagamentos;
3. períodos de conservação e processo de eliminação de conta;
4. política para dados comunitários e denúncias;
5. política de reembolsos/cancelamentos aplicável ao canal de venda escolhido;
6. versão final dos Termos e Política de Privacidade publicada também no site.

Estes textos são rascunhos de produto e devem ser revistos para a configuração comercial e jurídica real antes do lançamento.
