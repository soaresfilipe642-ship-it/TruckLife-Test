(()=>{
'use strict';
const $=s=>document.querySelector(s);
const API='/admin/v1';
let session=null;
let pendingAction=null;

function money(value,currency='EUR'){return new Intl.NumberFormat('pt-PT',{style:'currency',currency}).format(Number(value||0));}
function text(el,value){if(el)el.textContent=String(value??'');}
function sessionToken(){return session&&session.idToken?session.idToken:null;}
async function api(path,options={}){
  const token=sessionToken();
  if(!token)throw new Error('AUTH_REQUIRED');
  const headers=new Headers(options.headers||{});headers.set('Authorization','Bearer '+token);headers.set('Accept','application/json');
  if(options.body&&!headers.has('Content-Type'))headers.set('Content-Type','application/json');
  const res=await fetch(API+path,{...options,headers,credentials:'omit',cache:'no-store',redirect:'error'});
  if(res.status===401||res.status===403){lock();throw new Error('ADMIN_REQUIRED');}
  if(!res.ok)throw new Error('HTTP_'+res.status);
  return res.status===204?null:res.json();
}
function lock(){session=null;$('#dashboard').hidden=true;$('#loginPanel').hidden=false;$('#signOutBtn').disabled=true;$('#sessionBadge').className='badge warn';text($('#sessionBadge'),'Sessão por ligar');}
function unlock(s){session=s;$('#dashboard').hidden=false;$('#loginPanel').hidden=true;$('#signOutBtn').disabled=false;$('#sessionBadge').className='badge good';text($('#sessionBadge'),'Admin verificado');refresh();}
async function login(){
  // Future Firebase integration calls Google sign-in and passes only the short-lived ID token here.
  alert('Firebase/Google ainda não está ligado. Quando o configurarmos no computador, este botão fará o login real do proprietário.');
}
async function refresh(){
  try{
    const d=await api('/dashboard');
    text($('#totalUsers'),d.users?.total??0);text($('#trialUsers'),d.users?.trial??0);text($('#activeUsers'),d.users?.active??0);text($('#expiredUsers'),d.users?.expired??0);text($('#revenue30'),money(d.money?.gross30d,d.money?.currency||'EUR'));text($('#failedPayments'),d.payments?.failed30d??0);
    renderUsers(d.users?.recent||[]);renderPayments(d.payments?.recent||[]);renderList($('#moderationList'),d.moderation?.pending||[],x=>`${x.type||'Denúncia'} · ${x.createdAt||''}`);renderList($('#auditList'),d.audit?.recent||[],x=>`${x.action||'Ação'} · ${x.actor||''} · ${x.createdAt||''}`);
  }catch(e){console.error(e);}
}
function renderUsers(rows){const body=$('#usersBody');body.replaceChildren();if(!rows.length){emptyRow(body,5,'Sem dados do servidor.');return;}for(const u of rows){const tr=document.createElement('tr');cell(tr,u.email||u.uid||'');cellState(tr,u.status||'');cell(tr,u.entitlement||'');cell(tr,u.lastSeenAt||'');const td=document.createElement('td');const wrap=document.createElement('div');wrap.className='rowActions';const suspended=String(u.status||'').toUpperCase()==='SUSPENDED';wrap.appendChild(actionButton(suspended?'Reativar':'Suspender',()=>openAction(suspended?'reactivate':'suspend',u)));td.appendChild(wrap);tr.appendChild(td);body.appendChild(tr);}}
function renderPayments(rows){const body=$('#paymentsBody');body.replaceChildren();if(!rows.length){emptyRow(body,5,'Sem pagamentos do servidor.');return;}for(const p of rows){const tr=document.createElement('tr');cell(tr,p.paidAt||p.createdAt||'');cell(tr,p.user||p.uid||'');cell(tr,p.provider||'');cell(tr,money(p.amount,p.currency||'EUR'));cellState(tr,p.status||'');body.appendChild(tr);}}
function renderList(root,rows,label){root.replaceChildren();if(!rows.length){const d=document.createElement('div');d.className='listItem muted';d.textContent='Sem itens.';root.appendChild(d);return;}for(const x of rows.slice(0,20)){const d=document.createElement('div');d.className='listItem';d.textContent=label(x);root.appendChild(d);}}
function cell(tr,v){const td=document.createElement('td');td.textContent=String(v??'');tr.appendChild(td);}
function cellState(tr,v){const td=document.createElement('td'),span=document.createElement('span');span.className='state';span.textContent=String(v??'');td.appendChild(span);tr.appendChild(td);}
function emptyRow(body,n,msg){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=n;td.className='muted';td.textContent=msg;tr.appendChild(td);body.appendChild(tr);}
function actionButton(label,fn){const b=document.createElement('button');b.type='button';b.className='ghost';b.textContent=label;b.addEventListener('click',fn);return b;}
async function search(){const q=$('#userSearch').value.trim();if(!q)return refresh();try{const d=await api('/users/search?q='+encodeURIComponent(q));renderUsers(Array.isArray(d.users)?d.users:[]);}catch(e){console.error(e);}}
function openAction(kind,user){pendingAction={kind,user};text($('#modalTitle'),kind==='suspend'?'Suspender conta':'Reativar conta');text($('#modalText'),`${user.email||user.uid||'Utilizador'} — esta ação será registada no histórico administrativo.`);$('#actionReason').value='';$('#actionModal').hidden=false;}
function closeAction(){pendingAction=null;$('#actionModal').hidden=true;}
async function confirmAction(){if(!pendingAction)return;const reason=$('#actionReason').value.trim();if(reason.length<3){alert('Indica um motivo para a auditoria.');return;}const {kind,user}=pendingAction;try{await api(`/users/${encodeURIComponent(user.uid)}/${kind}`,{method:'POST',body:JSON.stringify({reason})});closeAction();await refresh();}catch(e){console.error(e);alert('Não foi possível concluir a ação.');}}

$('#loginBtn').addEventListener('click',login);$('#signOutBtn').addEventListener('click',lock);$('#refreshBtn').addEventListener('click',refresh);$('#searchBtn').addEventListener('click',search);$('#userSearch').addEventListener('keydown',e=>{if(e.key==='Enter')search();});$('#cancelAction').addEventListener('click',closeAction);$('#confirmAction').addEventListener('click',confirmAction);
window.TruckLifeAdmin={unlockForFirebase:unlock,lock};
lock();
})();
