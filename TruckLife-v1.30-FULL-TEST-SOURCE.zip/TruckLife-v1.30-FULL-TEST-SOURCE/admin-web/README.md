# Truck Life Admin Web — v1.27

Painel administrativo **separado** da aplicação Android dos motoristas.

## Segurança por desenho
- Não é distribuído dentro do APK público.
- Não guarda ID tokens em `localStorage`/`sessionStorage`; o token fica apenas em memória e deve ser curto.
- Cada pedido envia `Authorization: Bearer <Firebase ID token>`.
- O backend valida o token, confirma `admin=true` e aplica autorização novamente em cada pedido.
- O browser nunca recebe chaves privadas, service-account JSON, segredos de pagamentos ou credenciais bancárias.
- Ações sensíveis exigem motivo e o backend cria um registo de auditoria.
- Suspender/reativar contas e corrigir entitlements só acontece através do backend; nunca por escrita direta do browser no Firestore.

## Quando Firebase estiver configurado
1. Integrar Google/Firebase Authentication no botão de login.
2. Após login, obter ID token e chamar `TruckLifeAdmin.unlockForFirebase({idToken})`.
3. Servir este painel por HTTPS num domínio administrativo.
4. Adicionar MFA/2SV na conta Google do proprietário.
5. Configurar cabeçalhos HTTP: CSP, HSTS, `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, `Permissions-Policy` restritiva e `frame-ancestors 'none'`.
