# Truck Life — auditoria funcional v1.28

## Estado verificado na base
- Ecrãs principais presentes: Início, Mapa, Diário, Minha Viagem, CMR, Comunidade, Perfil, Veículo/Alertas, Tacógrafo, Assistente IA, Conta e Subscrição.
- Trial/subscrição: regras locais de demonstração e bloqueio Premium preparadas; autoridade final deve vir do servidor.
- Dados locais: Diário, documentos, viagens, perfil, veículos e alertas usam armazenamento local e estão preparados para fila de sincronização.
- Galeria: fluxo mantém seleção de fotografias já existente; câmara interna permanece fora do produto.
- Exportação: interface preparada para exportar cópia; validação completa depende do APK nativo recompilado.
- Notificações: preferências e ponte nativa estão preparadas; entrega real precisa do APK recompilado e teste em Android.
- Admin: retirado do APK público; painel web é separado.

## Ainda não validável sem computador/serviços reais
- Build Android v1.28 assinado e instalação em dispositivo.
- Google/Firebase Authentication real.
- Firestore/backend e sincronização multi-dispositivo.
- Conta ADMIN real e regras de servidor.
- Pagamentos reais e webhooks.
- Testes de segurança contra backend real.
- Navegação GPS/HGV e integração iGO/alternativa.
- Bluetooth/tacógrafo real em hardware compatível.

## Critério de conclusão
A aplicação só deve ser considerada pronta para lançamento após build assinado, testes em dispositivo real, backend real, pagamentos de teste, auditoria de segurança e validação GPS/HGV.
