# Truck Life v1.29 test

## Bluetooth / tacógrafo
- Pesquisa Bluetooth LE nativa no Android.
- Permissões Android 12+ (`BLUETOOTH_SCAN` e `BLUETOOTH_CONNECT`).
- Emparelhamento/bonding com confirmação no telemóvel e no tacógrafo.
- Ligação GATT e descoberta dos serviços ITS normalizados do Smart Tachograph v2.
- Transporte BLE FIFO + créditos preparado para Download e Diagnostics.
- Ecrã Tacógrafo atualizado com estado real da ligação.
- O protocolo de descarga/decodificação de jornadas (nível superior ao BLE) continua separado e precisa de validação com hardware real antes de ser considerado funcional.

## Subscrições
- 1 mês: 5 EUR.
- 6 meses: 9 EUR.
- 12 meses: 12 EUR.
- IDs de produto separados para cada plano.

## Instalação de teste
- Package: `com.trucklife.prototest`.
- Version name: `1.29-test`.
- Não substitui a instalação de produção com package diferente.
