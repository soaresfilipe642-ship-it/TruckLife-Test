# Controlled migration from the installed v1.10

The currently installed Truck Life v1.10 uses package id `com.trucklife.prototype` and an older signing certificate.
The recovered/new v1.20 package cannot update it in-place because the signing certificate is different.

## Rule until migration day
Do not uninstall, clear data, or replace the installed v1.10.

## Production migration plan
1. Finish and test the new source before touching the installed app.
2. Establish one permanent production signing key and keep it for every future release.
3. Preserve/export any user data from the old v1.10 before uninstalling it.
4. Remove the old package only after the data backup has been verified.
5. Install the new production build using the same package id `com.trucklife.prototype`.
6. Import/restore the preserved data and verify it.
7. From then on, all updates use the same permanent signing key and can update normally.

## Certificate note
The installed v1.10 APK recovered from the project history is signed with a v2 certificate whose SHA-256 fingerprint is:
`9191b091a5aa67fdb2049e9bbb193ffcf2d0f52e2f2e0b0abf07e476f399e8b7`

The preserved v1.20 MAPA-COBERTURA APK uses a different certificate, so Android correctly rejects it as an in-place update.
