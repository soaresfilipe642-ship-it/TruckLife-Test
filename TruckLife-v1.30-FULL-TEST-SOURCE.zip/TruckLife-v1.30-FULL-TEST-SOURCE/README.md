# Truck Life v1.28 — MASTER SOURCE

Canonical working source reconstructed from the v1.20 MAPA-COBERTURA application assets.

## Current rules
- Production package id: `com.trucklife.prototype`
- Current source version: `1.28`
- Existing v1.10 installed on the phone must remain untouched for now.
- Do **not** try to install a newly signed v1.20 over the existing v1.10: their signing certificates differ.
- Map/navigation work is intentionally paused until the iGO reference files can be reviewed.

## Recovered modules
Home, Map, Trip, Diary, CMR/Documents, Community, AI, Profile, Vehicle/Alerts, Tachograph, Offline, translations and shared styling.

## Android shell
The original v1.20 Java/Kotlin project was not preserved, so the Android WebView shell was reconstructed. It supports:
- Internet
- Location/GPS permission and HTML geolocation
- Gallery/file picker
- No internal camera capture path

## Next engineering work
1. Stabilize and test the recovered source.
2. Implement Google-only account/login.
3. Add offline-first data layer and cloud synchronization.
4. Add real notifications/integrations.
5. Resume map/navigation after iGO analysis.
6. Before production migration, establish one permanent signing key and a controlled data-migration procedure.


## v1.21 access/subscription base
- Added shared 7-day trial / entitlement state module.
- Added Account & Subscription screen.
- Added status visibility on Home and Profile.
- Production Google authentication, backend verification, payment provider integration and admin dashboard remain intentionally unconnected until credentials/provider accounts are available.

## v1.24 account/cloud foundation
- Added a dedicated Google account screen and shared authentication state boundary.
- Added offline-first synchronization queue without duplicating large CMR/photo payloads in the queue.
- Existing screens keep writing locally first; tracked user-data keys are marked pending automatically.
- Added hooks for native Google login, server entitlement validation and cloud sync.
- Trial state can now accept authoritative server time/state, preventing phone-clock manipulation once backend is connected.
- Real Google/Firebase credentials and backend transport are intentionally not fabricated; see `GOOGLE-FIREBASE-SETUP.md` and `BACKEND-CLOUD.md`.


## v1.24
- camada de pagamentos preparada (Google Play / PayPal-cartão / MB WAY)
- confirmação de pagamento desenhada para validação no servidor
- painel administrativo base com trials, subscrições, pagamentos e receita
- papel ADMIN preparado na identidade do utilizador
- pagamentos reais continuam desligados até configurar fornecedores e backend


## v1.24
- política read-only aplicada após fim do trial/subscrição
- criação/edição premium bloqueada em Diário, CMR, Viagem, Veículos/Alertas, Comunidade e IA
- dados já guardados continuam consultáveis
- tentativas de escrita encaminham para Subscrição


## v1.26 export + Android reminders
- Added user-data export from Profile to a JSON backup chosen by the user through Android's document picker.
- Export remains available during read-only/expired access.
- Added native Android notification permission handling (Android 13+).
- Vehicle/document expiry alerts can now schedule Android reminders using the configured 30/15/7/1-day offsets.
- Reminder schedules are stored natively and restored after device reboot/app update.
- No external notification service is needed for local expiry reminders. Remote/community push notifications still require the future backend/Firebase push setup.


## Segurança v1.26

- A autorização de administrador deixou de confiar no `role` guardado em `localStorage`; até existir verificação real no backend, o painel permanece bloqueado.
- A tabela administrativa deixou de inserir dados do servidor com `innerHTML`.
- Backups Android automáticos foram desativados nesta base, tráfego cleartext foi bloqueado e WebView debugging foi explicitamente desligado.
- Ver `SECURITY-AUDIT.md` e `ADMIN-ARCHITECTURE.md`.

### Próxima ligação no computador
Quando Firebase estiver criado, a primeira tarefa de segurança é ligar `isAdminVerified()` à verificação real do ID token/custom claim e criar regras Firestore/Storage deny-by-default por UID. Depois entram App Check/Play Integrity e verificação server-side dos pagamentos.


## v1.28 — painel administrativo separado + segurança
- O painel de administração foi retirado do APK público e passou para `admin-web/`, pensado para ser servido por HTTPS num domínio administrativo.
- Preparada a interface do proprietário com métricas, pesquisa de utilizadores, pagamentos, suspensão/reativação, moderação e auditoria.
- O token administrativo não é persistido em Web Storage; cada pedido ao backend usa Bearer token e o servidor terá de validar `admin=true`.
- Adicionadas regras-base Firestore/Storage deny-by-default por UID em `backend/firebase/`.
- Entitlements, pagamentos, subscrições e audit log ficam server-only para escrita.
- Adicionado contrato inicial da Admin API e testes estáticos da fronteira administrativa.
- Ver `ADMIN-SECURITY-v1.28.md`.


## v1.28
Adiciona rascunhos de Privacidade/Termos no Perfil, auditoria funcional, auditoria de traduções e lista separada do bloco que exige computador/serviços reais.
