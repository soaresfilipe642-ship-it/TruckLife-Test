# Truck Life — auditoria de traduções v1.28

A infraestrutura i18n lista dezenas de idiomas europeus. O conteúdo mais completo está atualmente preparado para Português, Inglês, Espanhol, Francês, Alemão, Italiano, Neerlandês, Polaco e Romeno.

Os restantes idiomas têm apenas um núcleo parcial de termos e usam fallback para Inglês/Português quando não existe tradução específica. Antes do lançamento, a revisão deve garantir que botões, alertas, placeholders, ajuda, trial/subscrição, privacidade e mensagens de erro não ficam misturados entre idiomas.

Prioridade de lançamento recomendada para a revisão humana: PT, EN, ES, FR, DE, IT, NL, PL e RO. Depois ampliar os restantes idiomas sem prometer tradução integral enquanto houver fallback visível.
