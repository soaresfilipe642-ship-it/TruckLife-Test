# Truck Life v1.30 test — fonte completa

## Base
- Parte da fonte completa v1.29 (16 ecrãs, conta/cloud, subscrições, admin/backend, notificações/exportação).
- Mantém o package de teste `com.trucklife.prototest`.
- Versão Android: `1.30-test` / code `13001`.

## Bluetooth / tacógrafo
- Pesquisa BLE nativa.
- Permissões Android 12+.
- Emparelhamento/bonding.
- Ligação GATT.
- Deteção dos serviços Download e Diagnostics definidos para Smart Tachograph v2.
- FIFO + Credits preparados como transporte ITS.
- A leitura/decodificação da jornada e ficheiros continua em validação com hardware real; a app não a apresenta como concluída.

## Subscrições
- 1 mês: 5 EUR.
- 6 meses: 9 EUR.
- 12 meses: 12 EUR.

## Segurança
- `allowBackup=false`.
- `usesCleartextTraffic=false`.
- Chave de assinatura não incluída na fonte; assinatura de release usa variáveis de ambiente.
