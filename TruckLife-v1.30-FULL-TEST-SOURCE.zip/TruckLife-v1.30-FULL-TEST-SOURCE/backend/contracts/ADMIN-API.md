# Truck Life Admin API — contrato v1

Todos os endpoints `/admin/v1/*` exigem Firebase ID token válido e custom claim `admin=true`.

## Leitura
- `GET /admin/v1/dashboard` — métricas, utilizadores recentes, pagamentos, moderação e auditoria.
- `GET /admin/v1/users/search?q=` — pesquisa limitada por UID/e-mail.
- `GET /admin/v1/users/{uid}` — detalhe de conta, trial/subscrição e histórico administrativo.
- `GET /admin/v1/payments?cursor=` — pagamentos paginados.
- `GET /admin/v1/audit?cursor=` — log imutável de ações administrativas.

## Ações
- `POST /admin/v1/users/{uid}/suspend` body `{reason}`.
- `POST /admin/v1/users/{uid}/reactivate` body `{reason}`.
- `POST /admin/v1/users/{uid}/entitlement-adjust` body `{reason, state, endsAt}` — apenas suporte excecional; sempre auditado.
- `POST /admin/v1/moderation/{id}/resolve` body `{reason, action}`.

## Requisitos do servidor
- revalidar autorização em cada pedido;
- rate limit por admin/IP;
- `Cache-Control: no-store` em respostas administrativas;
- validação de esquema/tamanho de todos os corpos;
- idempotency key em operações que possam repetir;
- nunca devolver segredos, tokens de pagamento completos ou dados de cartão;
- cada mutação escreve `adminAudit` com ator, alvo, ação, motivo, hora e request id.
