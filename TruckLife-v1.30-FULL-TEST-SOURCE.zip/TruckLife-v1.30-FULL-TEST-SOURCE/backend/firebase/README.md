# Firebase security baseline

Estas regras são uma base conservadora para os dados já desenhados. Devem ser testadas no Firebase Emulator Suite antes de produção.

Princípios:
- `deny by default` no fim de Firestore e Storage;
- utilizador só acede ao próprio UID;
- `entitlements`, `payments`, `subscriptions` e `adminAudit` nunca são escritos pelo cliente;
- `admin=true` é uma custom claim atribuída apenas por Admin SDK/servidor;
- ações administrativas de alteração passam por endpoints do backend, com revalidação, motivo e audit log;
- uploads limitados a imagem/PDF e 15 MB nesta primeira base;
- App Check deve ser ativado quando o projeto Firebase existir.
