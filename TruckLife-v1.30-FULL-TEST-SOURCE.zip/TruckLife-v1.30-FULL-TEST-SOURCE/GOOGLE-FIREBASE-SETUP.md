# Ativação Google/Firebase — passo externo obrigatório

A app já tem a fronteira de autenticação/sincronização preparada, mas **não contém credenciais inventadas**.

Quando chegar a altura de ativar:
- criar/selecionar um projeto Firebase;
- registar Android package `com.trucklife.prototype`;
- usar a impressão digital SHA da chave de assinatura definitiva;
- ativar Authentication > Google;
- adicionar o ficheiro/configuração oficial fornecido pelo Firebase;
- ligar Firestore + Storage;
- implementar a ponte nativa `TruckLifeNative` usada por `auth.js` e `cloud_sync.js`.

A documentação Firebase atual recomenda Firebase Authentication com Credential Manager para Google Sign-In. Em setembro de 2026, a documentação oficial apresenta Firebase Android BoM 34.19.0 e Credential Manager 1.3.0 / Google ID 1.1.1 como exemplo de configuração. Rever versões no momento da ativação.
