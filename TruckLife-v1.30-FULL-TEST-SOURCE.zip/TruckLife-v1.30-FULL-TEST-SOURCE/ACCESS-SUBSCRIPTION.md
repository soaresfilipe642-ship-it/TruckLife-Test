# Truck Life — Conta, trial e subscrição

## Estado implementado na base v1.21

A interface já tem um módulo comum (`assets/access.js`) com estados `TRIAL`, `ACTIVE`, `EXPIRED` e `CANCELLED`, teste de 7 dias, acesso de leitura após expiração e ecrã de subscrição.

**Importante:** nesta versão o estado é apenas um simulador local para desenvolvimento. Não é segurança de produção.

## Produção

1. Login obrigatório com Google e UID único por conta Google.
2. O servidor cria `trialStartedAt`/`trialEndsAt`; o telemóvel nunca é a fonte de verdade para o relógio do trial.
3. O servidor devolve o entitlement atual e a data de validade.
4. Pagamentos atualizam o entitlement através de webhooks/validação do fornecedor.
5. Ao expirar: leitura/exportação dos dados pessoais continua; criação de novos registos e funções premium ficam bloqueadas.
6. O cliente mantém um cache assinado/validado do entitlement para tolerar períodos curtos offline e volta a validar quando liga à Internet.

## Estados

- `TRIAL`: 7 dias de acesso completo.
- `ACTIVE`: subscrição paga ativa.
- `EXPIRED`: trial/subscrição terminou.
- `CANCELLED`: renovação cancelada; se houver tempo pago restante, o backend pode manter `ACTIVE` até `subscriptionEndsAt` e só depois mudar para `EXPIRED`.

## Dados mínimos do backend

`users/{uid}`: perfil, idioma, createdAt, status.

`entitlements/{uid}`: state, trialStartedAt, trialEndsAt, subscriptionStartedAt, subscriptionEndsAt, provider, providerCustomerId, providerSubscriptionId, lastValidatedAt.

`payments/{paymentId}`: uid, provider, amount, currency, status, paidAt, externalReference.

O painel de administração deve ler estes dados através de uma API protegida e nunca expor dados completos de cartão.
