# Truck Life — Pagamentos e painel admin

## Planos pretendidos

- `trucklife_monthly_5_eur` — 1 mês — 5 EUR
- `trucklife_6month_9_eur` — 6 meses — 9 EUR
- `trucklife_annual_12_eur` — 12 meses — 12 EUR

O teste gratuito mantém-se em 7 dias, sem cartão. Depois do pagamento, o backend é a fonte de verdade do `subscriptionEndsAt` e valida recibos/webhooks do fornecedor.

## Fornecedores

A interface está preparada para Google Play, PayPal/cartão e MB WAY. Em produção, os IDs internos acima devem ser mapeados para produtos/base plans reais do fornecedor. A app nunca deve confiar apenas no estado local para desbloquear premium.

## Admin

O painel deve mostrar plano comprado, valor, fornecedor, estado do pagamento, início/fim da subscrição, renovações e receita agregada.
