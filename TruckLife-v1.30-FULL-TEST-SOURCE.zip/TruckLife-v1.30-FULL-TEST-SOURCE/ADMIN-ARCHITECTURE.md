# Truck Life — Arquitetura do Painel de Administração

## Forma recomendada
O painel principal deve ser uma aplicação web administrativa separada da app dos motoristas. Deve abrir no computador e no telemóvel através de navegador responsivo. Um APK administrativo separado pode ser criado no futuro, mas não deve ser a base da segurança nem conter segredos administrativos.

## Acesso
- Login do proprietário com Google/Firebase Authentication.
- Apenas o UID do proprietário recebe `admin=true` através do Firebase Admin SDK num ambiente servidor protegido.
- O cliente nunca pode criar, editar ou confiar num papel ADMIN guardado localmente.
- Cada pedido administrativo ao backend deve validar um Firebase ID token atual e confirmar a custom claim `admin=true`.
- Recomenda-se 2-Step Verification/passkey na conta Google proprietária e reautenticação para ações críticas.

## O que o painel mostra
- Total de utilizadores.
- Em teste de 7 dias / dias restantes.
- Subscrições ativas, expiradas e canceladas.
- Pagamentos confirmados, falhados/reembolsados e fornecedor.
- Receita por período e próximas renovações.
- Estado do backend, sincronização e erros relevantes.
- Pesquisa de utilizador por ID/e-mail quando necessário para suporte.

## Ações administrativas
- Consultar conta e estado de subscrição.
- Corrigir um estado apenas por fluxo administrativo auditado, nunca por alteração direta no cliente.
- Suspender/bloquear conta em caso de abuso.
- Rever denúncias/moderação da Comunidade.
- Consultar registo de auditoria.

## O que não deve estar no painel
- Números completos de cartões.
- CVV.
- Credenciais de PayPal/Google/MB WAY.
- Chaves privadas ou service-account JSON no navegador/APK.
- Documentos pessoais do motorista sem uma necessidade de suporte claramente definida.

## Backend
O backend é a autoridade para:
- início/fim do trial;
- entitlement Premium;
- pagamentos e renovações;
- papel ADMIN;
- bloqueios de conta;
- eventos de auditoria.

A app Android apenas apresenta o estado recebido. Nunca deve conseguir marcar-se a si própria como paga ou administradora.
