# Truck Life — Admin + Segurança v1.27

## Decisão de arquitetura
O painel administrativo passa a ser um site privado separado (`admin-web/`). A interface administrativa deixa de fazer parte dos assets públicos do APK, reduzindo a superfície de ataque e evitando que lógica de administração seja distribuída a todos os motoristas.

## Conta do proprietário
- login Google/Firebase;
- custom claim `admin=true` atribuída somente pelo backend/Admin SDK;
- 2-Step Verification/passkey obrigatória na conta Google usada para administração;
- token curto, mantido apenas em memória no browser;
- reautenticação prevista para ações críticas.

## Controlo disponível no painel
- métricas de utilizadores, trials, ativos e expirados;
- receita e pagamentos falhados;
- pesquisa por UID/e-mail;
- suspender/reativar conta com motivo obrigatório;
- moderação da comunidade;
- log de auditoria.

## Proteções preparadas
- Firestore e Storage com deny-by-default;
- isolamento por UID;
- entitlement/pagamento/admin sem escrita direta pelo cliente;
- uploads limitados por tipo e tamanho;
- Admin API com bearer token, rate limit e audit log;
- UI sem `innerHTML` para dados do servidor;
- nenhum token administrativo persistido no browser;
- painel fora do APK público.

## O que só pode ser validado quando o backend existir
- bypass de regras Firestore/Storage;
- custom claim falsificada;
- ID token expirado/revogado;
- App Check;
- rate limit real;
- webhooks e replay de pagamentos;
- enumeração de utilizadores;
- testes de sessão/admin em ambiente HTTPS real.
