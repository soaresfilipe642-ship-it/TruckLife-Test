# Truck Life — Auditoria de Segurança v1.27

## Estado
Primeira auditoria estática executada sobre a base v1.25 antes de ligar Firebase e pagamentos reais. Esta auditoria não substitui testes dinâmicos num APK de produção, pentest externo ou validação do backend depois de implementado.

## Achados corrigidos nesta versão
1. **CRÍTICO — função ADMIN dependia de `localStorage`.**
   - Antes: `auth.js` considerava administrador qualquer sessão cujo `role` local fosse `ADMIN`.
   - Risco: armazenamento local é controlado pelo dispositivo/cliente e não pode ser autoridade de privilégios.
   - v1.26: `isAdmin()` só aceita confirmação da ponte nativa; até o backend verificar token + custom claim, devolve falso.

2. **ALTO — dados administrativos eram inseridos com `innerHTML`.**
   - Risco: conteúdo vindo do backend/utilizador podia tornar-se XSS e executar JavaScript dentro do WebView.
   - v1.26: linhas da tabela de pagamentos usam `textContent`/nós DOM.

3. **MÉDIO — backup Android automático ativo.**
   - Risco: dados locais podiam entrar em mecanismos de backup do sistema sem uma política explícita.
   - v1.26: `android:allowBackup=false` até existir uma política deliberada de backup/cloud.

4. **MÉDIO — WebView debugging não estava explicitamente desligado.**
   - v1.26: `WebView.setWebContentsDebuggingEnabled(false)`.

5. **MÉDIO — tráfego HTTP simples não era explicitamente recusado.**
   - v1.26: `android:usesCleartextTraffic=false` e mixed content bloqueado.

## Riscos ainda abertos antes de produção
1. **Dados sensíveis em localStorage.** Diário, viagens, CMR, perfil e outros dados continuam maioritariamente no armazenamento WebView. Migrar dados críticos para armazenamento Android controlado, com proteção por Keystore quando adequado.
2. **WebView + JavascriptInterface.** A ponte nativa aumenta o impacto de uma eventual XSS. Manter navegação fechada a conteúdo confiável, reduzir métodos expostos e migrar para um esquema de assets/bridge com origem controlada antes do lançamento.
3. **Conteúdo dinâmico HTML.** Fazer revisão completa de todos os usos de `innerHTML`; cada valor externo deve ser escapado ou criado com `textContent`.
4. **Firebase ainda não ligado.** Criar Security Rules por UID, negar por defeito, e testes no Emulator Suite.
5. **App Check ainda não ligado.** Ativar App Check/Play Integrity depois de Firebase/assinatura definitiva.
6. **Pagamentos ainda não ligados.** Compra só dá Premium depois de verificação server-side. Webhooks devem ser autenticados, idempotentes e auditados.
7. **Trial ainda não é autoridade servidor.** O relógio/dispositivo não pode decidir a validade final.
8. **Assinatura definitiva ainda não estabelecida.** A chave de release deve ser única, permanente, protegida e nunca incluída no repositório.
9. **Admin real ainda não existe.** Custom claim deve ser atribuída apenas pelo Admin SDK/servidor e todos os endpoints administrativos devem validar token e claim.

## Testes obrigatórios antes de lançamento
- Static scan de segredos/chaves.
- Regras Firestore/Storage: testes positivos e negativos no emulator.
- Tentativas de ler/escrever dados de outro UID.
- Tentativa de mudar `trial`, `subscription`, `paid` e `admin` pelo cliente.
- Replay de recibos/purchase tokens.
- Webhook inválido/repetido/fora de ordem.
- XSS em nome, empresa, CMR, comentários, pesquisa e campos de admin.
- Upload de tipo/tamanho inesperado.
- Rate limiting em chat, reports, IA e endpoints administrativos.
- Sessão revogada, utilizador eliminado e token expirado.
- APK modificado/reempacotado e App Check/Play Integrity.
- MITM/HTTP cleartext e certificados inválidos.
- Backup/restauro e exportação de dados.
- Permissões Android e componentes exportados.
- Release build sem debug/test endpoints/chaves.

## Critério de lançamento
Nenhum achado CRÍTICO ou ALTO aberto. Achados MÉDIOS precisam de mitigação documentada e aceite antes de produção.


## Alterações v1.27
- Painel administrativo removido dos assets do APK público.
- Novo `admin-web/` separado, com token apenas em memória, bearer auth e CSP base.
- Regras Firestore/Storage base com deny-by-default e isolamento por UID.
- Escrita cliente em entitlements/pagamentos/subscrições/auditoria explicitamente recusada.
- Contrato da Admin API exige validação de admin por pedido, rate limiting e audit log.
