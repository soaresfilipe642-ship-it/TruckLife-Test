# Truck Life — Política de bloqueio após trial/subscrição (v1.24)

## Durante TRIAL ou ACTIVE
O motorista pode criar, editar e eliminar registos e usar as funções premium disponíveis.

## Depois de EXPIRED ou CANCELLED
A app mantém acesso de leitura aos dados pessoais já guardados, mas bloqueia alterações premium. Nesta versão foram ligados bloqueios em:
- Diário: guardar/alterar o dia e atividades;
- CMR/documentos: criar, editar e eliminar;
- Minha Viagem: alterar viagem, estados, terminar visita, editar/eliminar histórico;
- Veículo e alertas: criar, editar, renovar e eliminar;
- Comunidade: participação/votos;
- Assistente IA: novas consultas.

O utilizador é encaminhado para `subscription.html` quando tenta uma ação bloqueada.

## Ainda a fechar
- exportação de dados em modo read-only;
- bloqueio/limitação de disponibilidade em tempo real no mapa quando o mapa for fechado;
- validação autoritativa do entitlement no backend;
- regras finas para operações gratuitas que possam vir a existir.
