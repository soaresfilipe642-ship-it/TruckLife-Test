val trucklifeKeystorePath = System.getenv("TRUCKLIFE_KEYSTORE_PATH")
val trucklifeKeystorePassword = System.getenv("TRUCKLIFE_KEYSTORE_PASSWORD")
val trucklifeKeyAlias = System.getenv("TRUCKLIFE_KEY_ALIAS") ?: "trucklife"
val trucklifeKeyPassword = System.getenv("TRUCKLIFE_KEY_PASSWORD")

plugins {
    id("com.android.application")
}

android {
    buildFeatures {
        buildConfig = true
    }

    namespace = "com.trucklife.prototype"
    compileSdk = 37

    signingConfigs {
        create("trucklifeRelease") {
            if (trucklifeKeystorePath != null) {
                storeFile = file(trucklifeKeystorePath)
                storePassword = trucklifeKeystorePassword
                keyAlias = trucklifeKeyAlias
                keyPassword = trucklifeKeyPassword ?: trucklifeKeystorePassword
            }
        }
    }

    defaultConfig {
        applicationId = "com.trucklife.prototest"
        minSdk = 26
        targetSdk = 37
        versionCode = 13001
        versionName = "1.30-test"
    }

    buildTypes {
        getByName("release") {
            if (trucklifeKeystorePath != null) {
                signingConfig = signingConfigs.getByName("trucklifeRelease")
            }
        }
    }
}
