package com.trucklife.prototype;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Bluetooth LE transport for Smart Tachograph v2 ITS.
 *
 * Implements discovery, Android pairing/bonding, GATT connection, standard ITS
 * service discovery and indication setup.  The higher-level tachograph download
 * protocol (Appendix 7 commands and parsing) is intentionally kept separate.
 */
public final class TachographBluetoothManager {
    public static final int REQ_BLUETOOTH = 1101;
    public static final int REQ_ENABLE_BLUETOOTH = 1102;

    // Smart Tachograph v2 VU transport protocol for ITS (JRC/CORTE specification).
    private static final UUID DOWNLOAD_SERVICE = UUID.fromString("eef90782-55dd-4388-b80b-695aba7a69b5");
    private static final UUID DOWNLOAD_FIFO = UUID.fromString("29d3a479-1592-47df-80a4-afa742d369bb");
    private static final UUID DOWNLOAD_CREDITS = UUID.fromString("db9c4128-bff3-41fe-a306-fb6f9a8aeb2d");
    private static final UUID DIAGNOSTICS_SERVICE = UUID.fromString("fa213def-aef4-475c-bcea-0a8d69073efc");
    private static final UUID DIAGNOSTICS_FIFO = UUID.fromString("e413960c-75ba-4ca9-8a67-99bc052a1b13");
    private static final UUID DIAGNOSTICS_CREDITS = UUID.fromString("e168d1a6-304f-42b4-ab96-4cd1d4efebd9");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final long SCAN_MS = 15000L;

    private final Activity activity;
    private final WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final Map<String, JSONObject> devices = new LinkedHashMap<>();
    private final ArrayDeque<BluetoothGattDescriptor> descriptorQueue = new ArrayDeque<>();

    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private String pendingBondAddress;
    private String connectedAddress;
    private boolean scanning;
    private boolean receiverRegistered;
    private boolean itsReady;
    private BluetoothGattCharacteristic downloadCredits;

    public TachographBluetoothManager(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;
        registerBondReceiver();
    }

    public boolean isAvailable() {
        return adapter != null;
    }

    public boolean isEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    public boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            activity.requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_BLUETOOTH);
        } else if (Build.VERSION.SDK_INT >= 23) {
            activity.requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_BLUETOOTH);
        }
    }

    public void requestEnable() {
        if (adapter == null) {
            emit(simple("error", "BLUETOOTH_NOT_AVAILABLE"));
            return;
        }
        if (adapter.isEnabled()) {
            emit(simple("enabled", "Bluetooth já está ativo"));
            return;
        }
        activity.startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BLUETOOTH);
    }

    public void openSettings() {
        try {
            activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception ignored) { }
    }

    public String statusJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("available", isAvailable());
            o.put("enabled", isEnabled());
            o.put("permissions", hasPermissions());
            o.put("scanning", scanning);
            o.put("connectedAddress", connectedAddress == null ? JSONObject.NULL : connectedAddress);
            o.put("itsReady", itsReady);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public void startScan() {
        if (adapter == null) {
            emit(simple("error", "BLUETOOTH_NOT_AVAILABLE"));
            return;
        }
        if (!hasPermissions()) {
            emit(simple("permission_required", "É necessária autorização Bluetooth"));
            requestPermissions();
            return;
        }
        if (!adapter.isEnabled()) {
            emit(simple("bluetooth_disabled", "Ativa o Bluetooth para procurar o tacógrafo"));
            requestEnable();
            return;
        }

        stopScan();
        devices.clear();
        addBondedDevices();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            emit(simple("error", "BLE_SCANNER_UNAVAILABLE"));
            return;
        }
        scanning = true;
        emit(simple("scan_started", "A procurar tacógrafos Bluetooth LE…"));
        try {
            scanner.startScan(scanCallback);
            handler.postDelayed(this::stopScan, SCAN_MS);
        } catch (SecurityException e) {
            scanning = false;
            emit(simple("permission_required", "Permissão Bluetooth em falta"));
        }
    }

    public void stopScan() {
        handler.removeCallbacksAndMessages(null);
        if (scanning && scanner != null && hasPermissions()) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        if (scanning) emit(simple("scan_finished", "Pesquisa concluída"));
        scanning = false;
    }

    public void connect(String address) {
        if (adapter == null || address == null || address.trim().isEmpty()) {
            emit(simple("error", "INVALID_DEVICE"));
            return;
        }
        if (!hasPermissions()) {
            requestPermissions();
            emit(simple("permission_required", "É necessária autorização Bluetooth"));
            return;
        }
        if (!adapter.isEnabled()) {
            requestEnable();
            emit(simple("bluetooth_disabled", "Bluetooth desligado"));
            return;
        }
        stopScan();
        try {
            BluetoothDevice device = adapter.getRemoteDevice(address);
            emit(deviceEvent("connecting", device, 0, "A preparar ligação…"));
            if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                pendingBondAddress = address;
                boolean started = device.createBond();
                emit(deviceEvent(started ? "pairing" : "error", device, 0,
                        started ? "Confirma o código no telemóvel e no tacógrafo" : "Não foi possível iniciar o emparelhamento"));
                return;
            }
            connectGatt(device);
        } catch (Exception e) {
            emit(simple("error", "CONNECT_FAILED: " + safeMessage(e)));
        }
    }

    private void connectGatt(BluetoothDevice device) {
        closeGatt();
        itsReady = false;
        connectedAddress = device.getAddress();
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                gatt = device.connectGatt(activity, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } else {
                gatt = device.connectGatt(activity, false, gattCallback);
            }
        } catch (SecurityException e) {
            emit(simple("permission_required", "Permissão Bluetooth em falta"));
        }
    }

    public void disconnect() {
        itsReady = false;
        connectedAddress = null;
        closeGatt();
        emit(simple("disconnected", "Tacógrafo desligado"));
    }

    public boolean isItsReady() {
        return itsReady;
    }

    /**
     * Future hook for Appendix 7 payloads.  The BLE serial transport is ready,
     * but higher-level download commands must be validated before being sent.
     */
    public boolean sendDownloadPacket(String base64Payload) {
        if (!itsReady || gatt == null || base64Payload == null) return false;
        BluetoothGattService service = gatt.getService(DOWNLOAD_SERVICE);
        if (service == null) return false;
        BluetoothGattCharacteristic fifo = service.getCharacteristic(DOWNLOAD_FIFO);
        if (fifo == null) return false;
        try {
            byte[] data = Base64.decode(base64Payload, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 33) {
                return gatt.writeCharacteristic(fifo, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == 0;
            }
            fifo.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            fifo.setValue(data);
            return gatt.writeCharacteristic(fifo);
        } catch (Exception e) {
            return false;
        }
    }

    public void onPermissionResult() {
        try {
            JSONObject o = simple(hasPermissions() ? "permission_granted" : "permission_denied",
                    hasPermissions() ? "Bluetooth autorizado" : "Bluetooth não autorizado");
            o.put("granted", hasPermissions());
            emit(o);
        } catch (Exception ignored) { }
    }

    public void onEnableResult() {
        emit(simple(isEnabled() ? "enabled" : "bluetooth_disabled",
                isEnabled() ? "Bluetooth ativo" : "Bluetooth continua desligado"));
    }

    public void destroy() {
        stopScan();
        closeGatt();
        if (receiverRegistered) {
            try { activity.unregisterReceiver(bondReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
    }

    private void addBondedDevices() {
        try {
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                if (looksLikeTachograph(safeName(d))) {
                    JSONObject o = deviceJson(d, 0);
                    o.put("bonded", true);
                    devices.put(d.getAddress(), o);
                    emit(withType(o, "device"));
                }
            }
        } catch (Exception ignored) { }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            handleScanResult(result);
        }

        @Override
        public void onBatchScanResults(java.util.List<ScanResult> results) {
            if (results != null) for (ScanResult r : results) handleScanResult(r);
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            try {
                JSONObject o = simple("error", "Falha na pesquisa Bluetooth");
                o.put("code", errorCode);
                emit(o);
            } catch (Exception ignored) { }
        }
    };

    private void handleScanResult(ScanResult result) {
        if (result == null || result.getDevice() == null) return;
        BluetoothDevice device = result.getDevice();
        String name = safeName(device);
        boolean hasItsService = false;
        try {
            if (result.getScanRecord() != null && result.getScanRecord().getServiceUuids() != null) {
                for (android.os.ParcelUuid p : result.getScanRecord().getServiceUuids()) {
                    UUID u = p.getUuid();
                    if (DOWNLOAD_SERVICE.equals(u) || DIAGNOSTICS_SERVICE.equals(u)) {
                        hasItsService = true;
                        break;
                    }
                }
            }
        } catch (Exception ignored) { }
        if (!hasItsService && !looksLikeTachograph(name)) return;
        try {
            JSONObject o = deviceJson(device, result.getRssi());
            o.put("standardItsAdvertised", hasItsService);
            devices.put(device.getAddress(), o);
            emit(withType(o, "device"));
        } catch (Exception ignored) { }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectedAddress = g.getDevice().getAddress();
                emit(deviceEvent("connected", g.getDevice(), 0, "Bluetooth ligado; a validar serviço ITS…"));
                boolean mtuRequested = false;
                try { mtuRequested = g.requestMtu(247); } catch (Exception ignored) { }
                if (!mtuRequested) g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                itsReady = false;
                emit(deviceEvent("disconnected", g.getDevice(), 0,
                        status == BluetoothGatt.GATT_SUCCESS ? "Ligação terminada" : "Ligação Bluetooth perdida"));
                try { g.close(); } catch (Exception ignored) { }
                if (g == gatt) gatt = null;
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt g, int mtu, int status) {
            try {
                JSONObject o = simple("mtu", "MTU negociado");
                o.put("mtu", mtu);
                emit(o);
            } catch (Exception ignored) { }
            g.discoverServices();
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                emit(simple("error", "Não foi possível descobrir os serviços Bluetooth"));
                return;
            }
            BluetoothGattService download = g.getService(DOWNLOAD_SERVICE);
            BluetoothGattService diagnostics = g.getService(DIAGNOSTICS_SERVICE);
            if (download == null && diagnostics == null) {
                emit(deviceEvent("unsupported", g.getDevice(), 0,
                        "Emparelhado, mas este dispositivo não expõe o serviço ITS Smart Tachograph v2"));
                return;
            }
            descriptorQueue.clear();
            downloadCredits = null;
            if (download != null) {
                queueIndication(g, download.getCharacteristic(DOWNLOAD_FIFO));
                BluetoothGattCharacteristic credits = download.getCharacteristic(DOWNLOAD_CREDITS);
                queueIndication(g, credits);
                downloadCredits = credits;
            }
            if (diagnostics != null) {
                queueIndication(g, diagnostics.getCharacteristic(DIAGNOSTICS_FIFO));
                queueIndication(g, diagnostics.getCharacteristic(DIAGNOSTICS_CREDITS));
            }
            try {
                JSONObject o = deviceEvent("its_service_found", g.getDevice(), 0,
                        "Serviço ITS Smart Tachograph v2 encontrado");
                o.put("downloadService", download != null);
                o.put("diagnosticsService", diagnostics != null);
                emit(o);
            } catch (Exception ignored) { }
            writeNextDescriptor(g);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            writeNextDescriptor(g);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            handleCharacteristic(characteristic, characteristic.getValue());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            handleCharacteristic(characteristic, value);
        }
    };

    private void queueIndication(BluetoothGatt g, BluetoothGattCharacteristic c) {
        if (c == null) return;
        try {
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCCD);
            if (d != null) descriptorQueue.add(d);
        } catch (Exception ignored) { }
    }

    private void writeNextDescriptor(BluetoothGatt g) {
        BluetoothGattDescriptor d = descriptorQueue.poll();
        if (d != null) {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                } else {
                    d.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                    g.writeDescriptor(d);
                }
                return;
            } catch (Exception e) {
                writeNextDescriptor(g);
                return;
            }
        }
        itsReady = true;
        grantInitialCredits(g);
        emit(deviceEvent("its_ready", g.getDevice(), 0,
                "Ligação ITS Bluetooth pronta"));
    }

    private void grantInitialCredits(BluetoothGatt g) {
        if (downloadCredits == null) return;
        byte[] credits = new byte[]{20};
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(downloadCredits, credits, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            } else {
                downloadCredits.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                downloadCredits.setValue(credits);
                g.writeCharacteristic(downloadCredits);
            }
        } catch (Exception ignored) { }
    }

    private void handleCharacteristic(BluetoothGattCharacteristic characteristic, byte[] value) {
        if (characteristic == null || value == null) return;
        try {
            JSONObject o = simple("its_packet", "Dados recebidos do tacógrafo");
            o.put("characteristic", characteristic.getUuid().toString());
            o.put("base64", Base64.encodeToString(value, Base64.NO_WRAP));
            if (DOWNLOAD_CREDITS.equals(characteristic.getUuid()) || DIAGNOSTICS_CREDITS.equals(characteristic.getUuid())) {
                o.put("type", "credits");
                o.put("credits", value.length > 0 ? (value[0] & 0xff) : 0);
            }
            emit(o);
        } catch (Exception ignored) { }
    }

    private final BroadcastReceiver bondReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(intent.getAction())) return;
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (device == null) return;
            int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE);
            if (state == BluetoothDevice.BOND_BONDED) {
                emit(deviceEvent("paired", device, 0, "Emparelhamento concluído"));
                if (device.getAddress().equals(pendingBondAddress)) {
                    pendingBondAddress = null;
                    connectGatt(device);
                }
            } else if (state == BluetoothDevice.BOND_NONE && device.getAddress().equals(pendingBondAddress)) {
                pendingBondAddress = null;
                emit(deviceEvent("pairing_failed", device, 0, "Emparelhamento não concluído"));
            }
        }
    };

    private void registerBondReceiver() {
        IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        try {
            if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(bondReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            else activity.registerReceiver(bondReceiver, f);
            receiverRegistered = true;
        } catch (Exception ignored) { }
    }

    private void closeGatt() {
        if (gatt != null) {
            try { gatt.disconnect(); } catch (Exception ignored) { }
            try { gatt.close(); } catch (Exception ignored) { }
            gatt = null;
        }
    }

    private boolean looksLikeTachograph(String name) {
        if (name == null) return false;
        String n = name.toUpperCase(Locale.ROOT);
        return n.contains("DTCO") || n.contains("VDO") || n.contains("SE5000")
                || n.contains("STONERIDGE") || n.contains("TACHO") || n.contains("CONTINENTAL");
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null || n.trim().isEmpty() ? "Tacógrafo Bluetooth" : n;
        } catch (Exception e) {
            return "Tacógrafo Bluetooth";
        }
    }

    private JSONObject deviceJson(BluetoothDevice d, int rssi) throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", safeName(d));
        o.put("address", d.getAddress());
        o.put("rssi", rssi);
        o.put("bonded", d.getBondState() == BluetoothDevice.BOND_BONDED);
        o.put("likelyTachograph", looksLikeTachograph(safeName(d)));
        return o;
    }

    private JSONObject deviceEvent(String type, BluetoothDevice d, int rssi, String message) {
        try {
            JSONObject o = deviceJson(d, rssi);
            o.put("type", type);
            o.put("message", message);
            return o;
        } catch (Exception e) {
            return simple(type, message);
        }
    }

    private JSONObject simple(String type, String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("message", message);
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private JSONObject withType(JSONObject original, String type) {
        try {
            JSONObject copy = new JSONObject(original.toString());
            copy.put("type", type);
            return copy;
        } catch (Exception e) {
            return original;
        }
    }

    private String safeMessage(Exception e) {
        String s = e.getMessage();
        return s == null ? e.getClass().getSimpleName() : s;
    }

    private void emit(final JSONObject payload) {
        if (webView == null || payload == null) return;
        final String json = payload.toString();
        activity.runOnUiThread(() -> webView.evaluateJavascript(
                "if(window.truckLifeBluetoothEvent){window.truckLifeBluetoothEvent(" + JSONObject.quote(json) + ");}",
                null));
    }
}
