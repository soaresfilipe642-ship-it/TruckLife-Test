package com.trucklife.prototype;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_FILE = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int REQ_EXPORT = 1004;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingExportData;
    private TachographBluetoothManager tachographBluetooth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(true);
        }
        WebView.setWebContentsDebuggingEnabled(false);

        tachographBluetooth = new TachographBluetoothManager(this, webView);
        webView.addJavascriptInterface(new TruckLifeBridge(), "TruckLifeNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri != null ? uri.toString() : "";
                if (url.startsWith("file:///android_asset/") || url.startsWith("about:blank")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("file:///android_asset/") || url.startsWith("about:blank"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestLocationPermission();
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = filePathCallback;

                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);

                String type = "image/*";
                if (fileChooserParams != null &&
                        fileChooserParams.getAcceptTypes() != null &&
                        fileChooserParams.getAcceptTypes().length > 0 &&
                        fileChooserParams.getAcceptTypes()[0] != null &&
                        !fileChooserParams.getAcceptTypes()[0].isEmpty()) {
                    type = fileChooserParams.getAcceptTypes()[0];
                }
                pick.setType(type);

                // Deliberately gallery/file picker only: no camera capture intent.
                startActivityForResult(pick, REQ_FILE);
                return true;
            }
        });

        requestLocationPermission();
        webView.loadUrl("file:///android_asset/home.html");
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !hasLocationPermission()) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && pendingGeoCallback != null && pendingGeoOrigin != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
        if (requestCode == TachographBluetoothManager.REQ_BLUETOOTH && tachographBluetooth != null) {
            tachographBluetooth.onPermissionResult();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        } else if (requestCode == TachographBluetoothManager.REQ_ENABLE_BLUETOOTH) {
            if (tachographBluetooth != null) tachographBluetooth.onEnableResult();
        } else if (requestCode == REQ_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExportData != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Não foi possível abrir o ficheiro.");
                    out.write(pendingExportData.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Cópia dos dados exportada.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Falha ao exportar: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingExportData = null;
        }
    }

    public class TruckLifeBridge {
        @JavascriptInterface
        public boolean isGoogleAuthConfigured() {
            return false;
        }

        @JavascriptInterface
        public boolean isCloudSyncConfigured() {
            return false;
        }

        @JavascriptInterface
        public void startGoogleSignIn() {
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "Configuração Google/Firebase ainda não ligada.",
                    Toast.LENGTH_SHORT
            ).show());
        }

        @JavascriptInterface
        public void signOutGoogle() {
            // Implemented when Firebase Authentication is connected.
        }

        @JavascriptInterface
        public boolean syncLocalKey(String key, String operation, String value) {
            // Deliberately false until the authenticated backend transport is connected.
            return false;
        }

        @JavascriptInterface
        public boolean isBillingConfigured() {
            return false;
        }

        @JavascriptInterface
        public boolean startCheckout(String provider, String productId) {
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "Pagamentos ainda não ligados ao fornecedor de produção.",
                    Toast.LENGTH_SHORT
            ).show());
            return false;
        }

        @JavascriptInterface
        public void openManageSubscription() {
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "Gestão da subscrição será aberta quando o pagamento estiver ligado.",
                    Toast.LENGTH_SHORT
            ).show());
        }

        @JavascriptInterface
        public boolean notificationsEnabled() {
            if (Build.VERSION.SDK_INT < 33) return true;
            return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_NOTIFICATIONS
                ));
            }
        }

        @JavascriptInterface
        public boolean replaceAlertReminders(String json) {
            try {
                AlertReminderScheduler.replace(MainActivity.this, json);
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Não foi possível preparar os lembretes.",
                        Toast.LENGTH_SHORT
                ).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean exportUserData(String json) {
            if (json == null || json.trim().isEmpty()) return false;
            pendingExportData = json;
            runOnUiThread(() -> {
                try {
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                    Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    create.addCategory(Intent.CATEGORY_OPENABLE);
                    create.setType("application/json");
                    create.putExtra(Intent.EXTRA_TITLE, "TruckLife-backup-" + date + ".json");
                    startActivityForResult(create, REQ_EXPORT);
                } catch (Exception e) {
                    pendingExportData = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o exportador.", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        @JavascriptInterface
        public boolean isBluetoothAvailable() {
            return tachographBluetooth != null && tachographBluetooth.isAvailable();
        }

        @JavascriptInterface
        public boolean isBluetoothEnabled() {
            return tachographBluetooth != null && tachographBluetooth.isEnabled();
        }

        @JavascriptInterface
        public boolean hasBluetoothPermissions() {
            return tachographBluetooth != null && tachographBluetooth.hasPermissions();
        }

        @JavascriptInterface
        public void requestBluetoothPermissions() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.requestPermissions());
        }

        @JavascriptInterface
        public void requestEnableBluetooth() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.requestEnable());
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.openSettings());
        }

        @JavascriptInterface
        public void startTachographScan() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.startScan());
        }

        @JavascriptInterface
        public void stopTachographScan() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.stopScan());
        }

        @JavascriptInterface
        public void connectTachograph(String address) {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.connect(address));
        }

        @JavascriptInterface
        public void disconnectTachograph() {
            if (tachographBluetooth != null) runOnUiThread(() -> tachographBluetooth.disconnect());
        }

        @JavascriptInterface
        public String getTachographBluetoothStatus() {
            return tachographBluetooth == null ? "{}" : tachographBluetooth.statusJson();
        }

        @JavascriptInterface
        public boolean isTachographItsReady() {
            return tachographBluetooth != null && tachographBluetooth.isItsReady();
        }

        @JavascriptInterface
        public boolean sendTachographDownloadPacket(String base64Payload) {
            return tachographBluetooth != null && tachographBluetooth.sendDownloadPacket(base64Payload);
        }

        @JavascriptInterface
        public String getAppVersion() {
            return BuildConfig.VERSION_NAME;
        }
    }

    @Override
    protected void onDestroy() {
        if (tachographBluetooth != null) tachographBluetooth.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
