package com.trucklife.prototype;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

final class AlertReminderScheduler {
    private static final String PREFS = "trucklife_native_reminders";
    private static final String KEY_JSON = "scheduled_json";

    private AlertReminderScheduler() {}

    static void replace(Context context, String json) throws Exception {
        JSONArray oldItems = readSaved(context);
        cancelItems(context, oldItems);

        JSONArray items = json == null || json.trim().isEmpty() ? new JSONArray() : new JSONArray(json);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_JSON, items.toString())
                .apply();
        scheduleItems(context, items);
    }

    static void rescheduleSaved(Context context) {
        try {
            scheduleItems(context, readSaved(context));
        } catch (Exception ignored) { }
    }

    private static JSONArray readSaved(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = p.getString(KEY_JSON, "[]");
        try {
            return new JSONArray(raw == null ? "[]" : raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void scheduleItems(Context context, JSONArray items) throws Exception {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long now = System.currentTimeMillis();
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at", 0L);
            if (at <= now) continue;
            PendingIntent pi = reminderIntent(context, o, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static void cancelItems(Context context, JSONArray items) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            PendingIntent pi = reminderIntent(context, o, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }
    }

    private static PendingIntent reminderIntent(Context context, JSONObject o, int flags) {
        String id = o.optString("id", "reminder");
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction("com.trucklife.prototype.REMINDER." + id);
        intent.putExtra("title", o.optString("title", "Truck Life"));
        intent.putExtra("body", o.optString("body", "Tens um alerta Truck Life."));
        intent.putExtra("notification_id", stableId(id));
        return PendingIntent.getBroadcast(context, stableId(id), intent, flags);
    }

    private static int stableId(String value) {
        int id = value == null ? 1 : value.hashCode();
        if (id == Integer.MIN_VALUE) id = 1;
        return Math.abs(id == 0 ? 1 : id);
    }
}
