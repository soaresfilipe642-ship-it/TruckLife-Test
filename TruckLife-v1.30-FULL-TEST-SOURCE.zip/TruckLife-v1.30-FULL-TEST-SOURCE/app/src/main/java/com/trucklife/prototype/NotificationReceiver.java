package com.trucklife.prototype;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class NotificationReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "trucklife_vehicle_alerts";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel c = new NotificationChannel(
                        CHANNEL_ID,
                        "Validades e lembretes Truck Life",
                        NotificationManager.IMPORTANCE_HIGH
                );
                c.setDescription("Seguros, inspeções, documentos e outros alertas guardados na Truck Life.");
                nm.createNotificationChannel(c);
            }

            Intent open = new Intent(context, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int id = intent != null ? intent.getIntExtra("notification_id", 1) : 1;
            PendingIntent content = PendingIntent.getActivity(
                    context,
                    id,
                    open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            String title = intent != null ? intent.getStringExtra("title") : null;
            String body = intent != null ? intent.getStringExtra("body") : null;
            Notification n = new Notification.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title == null || title.isEmpty() ? "Truck Life" : title)
                    .setContentText(body == null || body.isEmpty() ? "Tens um alerta Truck Life." : body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true)
                    .setContentIntent(content)
                    .build();
            nm.notify(id, n);
        } catch (SecurityException ignored) {
            // Android 13+: sem permissão POST_NOTIFICATIONS não mostramos nada.
        }
    }
}
