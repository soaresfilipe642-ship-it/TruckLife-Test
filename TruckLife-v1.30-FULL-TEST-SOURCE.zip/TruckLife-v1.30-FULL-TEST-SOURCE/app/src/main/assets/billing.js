(function(){
'use strict';
const KEY='tl_billing_v2';
const PRODUCTS={
  monthly:{id:'trucklife_monthly_5_eur',label:'1 mês',priceEur:5,currency:'EUR',period:'P1M',months:1},
  six_months:{id:'trucklife_6month_9_eur',label:'6 meses',priceEur:9,currency:'EUR',period:'P6M',months:6},
  annual:{id:'trucklife_annual_12_eur',label:'12 meses',priceEur:12,currency:'EUR',period:'P1Y',months:12}
};
const PRODUCT_LIST=Object.values(PRODUCTS);
const PROVIDERS=['GOOGLE_PLAY','PAYPAL_CARD','MBWAY'];
function parse(raw,fallback){try{return JSON.parse(raw)}catch(e){return fallback}}
function byId(id){return PRODUCT_LIST.find(p=>p.id===id)||PRODUCTS.annual}
function load(){const v=parse(localStorage.getItem(KEY),null);return v&&v.schema===2?v:{schema:2,state:'IDLE',provider:null,productId:PRODUCTS.annual.id,lastAttemptAt:null,lastError:null,lastReceiptId:null,updatedAt:Date.now()}}
function save(v){v.schema=2;v.updatedAt=Date.now();localStorage.setItem(KEY,JSON.stringify(v));render();return v}
function nativeConfigured(){try{return !!(window.TruckLifeNative&&window.TruckLifeNative.isBillingConfigured&&window.TruckLifeNative.isBillingConfigured())}catch(e){return false}}
function normalizeProvider(p){p=String(p||'').toUpperCase();return PROVIDERS.includes(p)?p:null}
function selectProduct(productId){const p=byId(productId);const v=load();v.productId=p.id;save(v);return p}
function startCheckout(provider,productId){
  const p=normalizeProvider(provider),product=byId(productId||load().productId);
  if(!p)return {ok:false,reason:'UNKNOWN_PROVIDER'};
  if(window.TL_AUTH&&!TL_AUTH.isSignedIn())return {ok:false,reason:'AUTH_REQUIRED'};
  if(!nativeConfigured())return {ok:false,reason:'BILLING_NOT_CONFIGURED'};
  const v=load();v.state='CHECKOUT';v.provider=p;v.productId=product.id;v.lastAttemptAt=Date.now();v.lastError=null;save(v);
  try{
    const r=window.TruckLifeNative.startCheckout(p,product.id);
    if(r===false||r==='false'){v.state='ERROR';v.lastError='CHECKOUT_REJECTED';save(v);return {ok:false,reason:'CHECKOUT_REJECTED'}}
    return {ok:true,product};
  }catch(e){v.state='ERROR';v.lastError=String(e);save(v);return {ok:false,reason:'NATIVE_ERROR',error:String(e)}}
}
function applyPurchaseResult(payload){
  const p=typeof payload==='string'?parse(payload,null):payload;
  if(!p||!p.status)return {ok:false,reason:'INVALID_RESULT'};
  const v=load();v.provider=normalizeProvider(p.provider)||v.provider;v.productId=p.productId||v.productId;v.lastReceiptId=p.receiptId||null;v.lastError=p.error||null;
  const status=String(p.status).toUpperCase();
  if(status==='VERIFIED'){
    v.state='VERIFIED';save(v);
    if(window.TL_ACCESS&&p.entitlement)TL_ACCESS.applyServerEntitlement(p.entitlement);
    return {ok:true,state:'VERIFIED'};
  }
  if(status==='CANCELLED'){v.state='CANCELLED';save(v);return {ok:false,reason:'CANCELLED'}}
  v.state='ERROR';save(v);return {ok:false,reason:p.error||'PAYMENT_FAILED'};
}
function manage(){try{if(window.TruckLifeNative&&window.TruckLifeNative.openManageSubscription)window.TruckLifeNative.openManageSubscription()}catch(e){}}
function label(){const v=load();if(v.state==='CHECKOUT')return 'Pagamento em curso';if(v.state==='VERIFIED')return 'Pagamento confirmado';if(v.state==='ERROR')return 'Erro no pagamento';if(v.state==='CANCELLED')return 'Pagamento cancelado';return 'Pronto para subscrever'}
function render(){const v=load();document.querySelectorAll('[data-tl-billing-state]').forEach(el=>el.textContent=label());document.querySelectorAll('[data-tl-billing-ready]').forEach(el=>el.textContent=nativeConfigured()?'Pagamentos ligados':'Pagamentos por ligar');document.querySelectorAll('[data-product-id]').forEach(el=>el.classList.toggle('selected',el.dataset.productId===v.productId))}
window.TL_BILLING={PRODUCTS,PRODUCT_LIST,PROVIDERS,get:load,byId,nativeConfigured,selectProduct,startCheckout,applyPurchaseResult,manage,label,render};
window.truckLifePurchaseResult=function(json){return applyPurchaseResult(json)};
document.addEventListener('DOMContentLoaded',render);
})();
