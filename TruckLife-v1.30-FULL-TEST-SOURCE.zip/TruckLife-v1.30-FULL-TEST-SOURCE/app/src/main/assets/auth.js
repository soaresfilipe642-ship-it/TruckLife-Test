(function(){
'use strict';
const KEY='tl_auth_v1';
const SCHEMA=1;
function parse(raw,fallback){try{return JSON.parse(raw)}catch(e){return fallback}}
function load(){const v=parse(localStorage.getItem(KEY),null);return v&&v.schema===SCHEMA?v:{schema:SCHEMA,state:'SIGNED_OUT',provider:null,uid:null,email:null,displayName:null,photoUrl:null,role:'DRIVER',verifiedAt:null,updatedAt:Date.now()}}
function save(v){v.schema=SCHEMA;v.updatedAt=Date.now();localStorage.setItem(KEY,JSON.stringify(v));window.dispatchEvent(new CustomEvent('tl-auth-changed',{detail:v}));return v}
function isSignedIn(){return load().state==='SIGNED_IN'&&!!load().uid}
function uid(){return load().uid||null}
function nativeConfigured(){try{return !!(window.TruckLifeNative&&window.TruckLifeNative.isGoogleAuthConfigured&&window.TruckLifeNative.isGoogleAuthConfigured())}catch(e){return false}}
function startGoogle(){
  if(!nativeConfigured()){
    const msg='A ligação Google está preparada na app, mas ainda precisa da configuração do projeto Google/Firebase para ficar ativa.';
    window.dispatchEvent(new CustomEvent('tl-auth-message',{detail:{type:'setup',message:msg}}));
    return {ok:false,reason:'NOT_CONFIGURED'};
  }
  try{window.TruckLifeNative.startGoogleSignIn();return {ok:true}}catch(e){return {ok:false,reason:'NATIVE_ERROR',message:String(e)}}
}
function acceptGoogleResult(payload){
  const p=typeof payload==='string'?parse(payload,null):payload;
  if(!p||!p.uid) return {ok:false,reason:'INVALID_RESULT'};
  const v=save({schema:SCHEMA,state:'SIGNED_IN',provider:'google',uid:String(p.uid),email:p.email||null,displayName:p.displayName||null,photoUrl:p.photoUrl||null,role:'DRIVER',verifiedAt:p.verifiedAt||Date.now(),updatedAt:Date.now()});
  if(window.TL_ACCESS&&TL_ACCESS.onAccountChanged)TL_ACCESS.onAccountChanged(v);
  if(window.TL_SYNC&&TL_SYNC.flush)TL_SYNC.flush();
  return {ok:true,user:v};
}
function signOut(){
  try{if(window.TruckLifeNative&&window.TruckLifeNative.signOutGoogle)window.TruckLifeNative.signOutGoogle()}catch(e){}
  return save({schema:SCHEMA,state:'SIGNED_OUT',provider:null,uid:null,email:null,displayName:null,photoUrl:null,role:'DRIVER',verifiedAt:null,updatedAt:Date.now()});
}
function render(){
  const a=load();
  document.querySelectorAll('[data-tl-auth-state]').forEach(el=>el.textContent=isSignedIn()?'Google ligado':'Google por ligar');
  document.querySelectorAll('[data-tl-auth-email]').forEach(el=>el.textContent=a.email||'');
  document.querySelectorAll('[data-tl-auth-name]').forEach(el=>el.textContent=a.displayName||'');
  document.querySelectorAll('[data-tl-auth-config]').forEach(el=>el.textContent=nativeConfigured()?'Configuração Google disponível':'Configuração Google pendente');
}
window.TL_AUTH={get:load,isSignedIn,uid,nativeConfigured,startGoogle,acceptGoogleResult,signOut,render};
// Native Android bridge calls this after a successful Google/Firebase sign-in.
window.truckLifeGoogleAuthResult=function(json){return acceptGoogleResult(json)};
document.addEventListener('DOMContentLoaded',render);
window.addEventListener('tl-auth-changed',render);
})();
