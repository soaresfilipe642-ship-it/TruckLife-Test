(function(){
'use strict';
const LEGACY_KEY='tl_entitlement_v1';
const PREFIX='tl_entitlement_user_v1_';
const TRIAL_DAYS=7;
const SUBSCRIPTION_PRICES={monthly:5,sixMonths:9,annual:12};
const DAY=24*60*60*1000;
let serverClockOffset=0;
function parse(raw,fallback){try{return JSON.parse(raw)}catch(e){return fallback}}
function authUid(){try{return window.TL_AUTH&&TL_AUTH.uid?TL_AUTH.uid():null}catch(e){return null}}
function key(){const uid=authUid();return uid?PREFIX+uid:LEGACY_KEY}
function clientNow(){return Date.now()}
function now(){return clientNow()+serverClockOffset}
function freshLocal(){return {schema:2,mode:'prototype-local',state:'TRIAL',trialStartedAt:now(),trialEndsAt:now()+TRIAL_DAYS*DAY,subscriptionEndsAt:null,provider:null,serverVerifiedAt:null,updatedAt:now()}}
function load(){
  const k=key();
  let saved=parse(localStorage.getItem(k),null);
  if(saved&&saved.schema===2)return saved;
  if(saved&&saved.schema===1){saved.schema=2;saved.serverVerifiedAt=null;localStorage.setItem(k,JSON.stringify(saved));return saved}
  // First time a Google account is attached: migrate the existing local trial state once,
  // until the backend returns its authoritative entitlement.
  if(authUid()&&k!==LEGACY_KEY){
    const legacy=parse(localStorage.getItem(LEGACY_KEY),null);
    if(legacy){saved=Object.assign({},legacy,{schema:2,migratedFromLegacy:true,updatedAt:now()});localStorage.setItem(k,JSON.stringify(saved));return saved}
  }
  saved=freshLocal();localStorage.setItem(k,JSON.stringify(saved));return saved;
}
function save(v){v.schema=2;v.updatedAt=now();localStorage.setItem(key(),JSON.stringify(v));return v}
function normalized(){
  const v=load(),t=now();
  if(v.state==='ACTIVE'&&v.subscriptionEndsAt&&t>=v.subscriptionEndsAt){v.state='EXPIRED';save(v)}
  if(v.state==='TRIAL'&&v.trialEndsAt&&t>=v.trialEndsAt){v.state='EXPIRED';save(v)}
  return v;
}
function applyServerEntitlement(payload){
  const p=typeof payload==='string'?parse(payload,null):payload;
  if(!p||!p.state)return {ok:false,reason:'INVALID_ENTITLEMENT'};
  if(Number.isFinite(Number(p.serverNow)))serverClockOffset=Number(p.serverNow)-clientNow();
  const v={schema:2,mode:'server',state:String(p.state).toUpperCase(),trialStartedAt:p.trialStartedAt||null,trialEndsAt:p.trialEndsAt||null,subscriptionEndsAt:p.subscriptionEndsAt||null,provider:p.provider||null,serverVerifiedAt:now(),updatedAt:now()};
  save(v);renderBadges();return {ok:true,value:v};
}
function daysLeft(v=normalized()){const end=v.state==='ACTIVE'?v.subscriptionEndsAt:v.trialEndsAt;if(!end)return 0;return Math.max(0,Math.ceil((end-now())/DAY))}
function hasPremium(){const v=normalized();return v.state==='TRIAL'||v.state==='ACTIVE'}
function canCreate(){return hasPremium()}
function canRead(){return true}
function isReadOnly(){return !hasPremium()}
function requireWrite(actionName){return requireCreate(actionName||'alterar dados')}
function label(v=normalized()){
  if(v.state==='TRIAL')return `Teste grátis · ${daysLeft(v)} dia(s)`;
  if(v.state==='ACTIVE')return `Subscrição ativa · ${daysLeft(v)} dia(s)`;
  if(v.state==='CANCELLED')return 'Subscrição cancelada';
  return 'Subscrição expirada';
}
function statusClass(v=normalized()){return (v.state==='TRIAL'||v.state==='ACTIVE')?'ok':'bad'}
function openSubscription(){location.href='subscription.html'}
function requireCreate(actionName){if(canCreate())return true;const msg=`O teu teste/subscrição terminou. Para ${actionName||'criar novos registos'}, ativa a subscrição Truck Life.`;alert(window.TL_I18N?TL_I18N.t(msg):msg);openSubscription();return false}
function onAccountChanged(){load();renderBadges()}
// Development-only helper, not exposed in normal UI.
function _devSet(state,days){const v=load();v.mode='prototype-local';v.state=state;const end=now()+Math.max(0,Number(days||0))*DAY;if(state==='TRIAL')v.trialEndsAt=end;if(state==='ACTIVE')v.subscriptionEndsAt=end;if(state!=='ACTIVE')v.subscriptionEndsAt=null;return save(v)}
function renderBadges(){const v=normalized();document.querySelectorAll('[data-tl-entitlement]').forEach(el=>{el.textContent=label(v);el.dataset.state=v.state;el.classList.toggle('entitlementBad',!hasPremium())});document.querySelectorAll('[data-tl-days-left]').forEach(el=>el.textContent=String(daysLeft(v)));document.querySelectorAll('[data-tl-price]').forEach(el=>el.textContent=SUBSCRIPTION_PRICES.annual.toFixed(2).replace('.',',')+' € / 12 meses')}
window.TL_ACCESS={TRIAL_DAYS,SUBSCRIPTION_PRICES,get:normalized,daysLeft,hasPremium,canCreate,canRead,isReadOnly,label,statusClass,requireCreate,requireWrite,openSubscription,applyServerEntitlement,onAccountChanged,_devSet,renderBadges};
window.truckLifeEntitlementResult=function(json){return applyServerEntitlement(json)};
document.addEventListener('DOMContentLoaded',renderBadges);window.addEventListener('tl-auth-changed',onAccountChanged);
})();
