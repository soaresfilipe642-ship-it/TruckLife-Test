(function(){
'use strict';
const QUEUE='tl_sync_queue_v1';
const META='tl_sync_meta_v1';
const SCHEMA=1;
const SYNC_KEYS=new Set([
  'tl_profile_v1','tl_settings_v1','tl_vehicle_alerts_v1','tl_vehicles_v1',
  'trucklife_diary_v04','trucklife_docs_v10','trucklife_rate_v04','trucklife_trip_v06','trucklife_visits_v06',
  'trucklife_map_favs'
]);
function parse(raw,fallback){try{return JSON.parse(raw)}catch(e){return fallback}}
const proto=Storage.prototype;
const nativeSet=proto.setItem;
const nativeRemove=proto.removeItem;
function queue(){const q=parse(nativeGet(QUEUE),[]);return Array.isArray(q)?q:[]}
function nativeGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function writeQueue(q){try{nativeSet.call(localStorage,QUEUE,JSON.stringify(q.slice(-250)))}catch(e){}}
function enqueue(key,op){
  if(!SYNC_KEYS.has(key))return;
  let q=queue().filter(x=>x.key!==key);
  q.push({key,op,queuedAt:Date.now()});
  writeQueue(q);
  setMeta({state:'PENDING',lastError:null});
  window.dispatchEvent(new CustomEvent('tl-sync-changed'));
}
function meta(){const m=parse(nativeGet(META),null);return m&&typeof m==='object'?m:{schema:SCHEMA,state:'LOCAL_ONLY',lastAttemptAt:null,lastSuccessAt:null,lastError:null}}
function setMeta(patch){const m=Object.assign(meta(),patch,{schema:SCHEMA});try{nativeSet.call(localStorage,META,JSON.stringify(m))}catch(e){}return m}
proto.setItem=function(key,value){const r=nativeSet.call(this,key,value);if(this===localStorage&&key!==QUEUE&&key!==META)enqueue(String(key),'UPSERT');return r};
proto.removeItem=function(key){const r=nativeRemove.call(this,key);if(this===localStorage&&key!==QUEUE&&key!==META)enqueue(String(key),'DELETE');return r};
function pendingCount(){return queue().length}
function stateLabel(){
  const n=pendingCount(),a=window.TL_AUTH&&TL_AUTH.isSignedIn&&TL_AUTH.isSignedIn();
  if(!a)return n?`${n} alteração(ões) aguardam conta Google`:'Dados locais · Google por ligar';
  if(!(window.TruckLifeNative&&window.TruckLifeNative.isCloudSyncConfigured&&window.TruckLifeNative.isCloudSyncConfigured()))return n?`${n} alteração(ões) aguardam cloud`:'Conta Google ligada · cloud por configurar';
  return n?`${n} alteração(ões) por sincronizar`:'Sincronizado';
}
async function flush(){
  setMeta({lastAttemptAt:Date.now()});
  if(!(window.TL_AUTH&&TL_AUTH.isSignedIn&&TL_AUTH.isSignedIn())){setMeta({state:'WAITING_AUTH'});render();return {ok:false,reason:'WAITING_AUTH'}}
  if(!(window.TruckLifeNative&&window.TruckLifeNative.isCloudSyncConfigured&&window.TruckLifeNative.isCloudSyncConfigured())){setMeta({state:'WAITING_BACKEND'});render();return {ok:false,reason:'WAITING_BACKEND'}}
  // Transport is deliberately native/server-controlled. Values are read only at send time,
  // so the queue stays small even when CMR photos are large.
  let q=queue();
  for(const item of q){
    const value=item.op==='DELETE'?null:nativeGet(item.key);
    try{
      const result=window.TruckLifeNative.syncLocalKey(item.key,item.op,value||'');
      if(result!==true&&result!=='true')throw new Error('SYNC_REJECTED');
      q=q.filter(x=>x.key!==item.key);writeQueue(q);
    }catch(e){setMeta({state:'ERROR',lastError:String(e)});render();return {ok:false,reason:'ERROR',error:String(e)}}
  }
  setMeta({state:'SYNCED',lastSuccessAt:Date.now(),lastError:null});render();return {ok:true};
}
function render(){const text=stateLabel();document.querySelectorAll('[data-tl-sync-state]').forEach(el=>el.textContent=text);document.querySelectorAll('[data-tl-sync-count]').forEach(el=>el.textContent=String(pendingCount()))}
function snapshot(){const out={};SYNC_KEYS.forEach(k=>{const v=nativeGet(k);if(v!==null)out[k]=v});return out}
window.TL_SYNC={keys:[...SYNC_KEYS],pendingCount,stateLabel,flush,render,snapshot,meta};
document.addEventListener('DOMContentLoaded',render);window.addEventListener('tl-sync-changed',render);window.addEventListener('tl-auth-changed',()=>{render();flush()});window.addEventListener('online',flush);
})();
