# Truck Life v1.20 — Recovered Source

Base: TruckLife v1.20 MAPA-COBERTURA.

Recovered exactly from the APK:
- home.html
- map.html
- map_fallback.html
- trip.html
- diary.html
- cmr.html
- community.html
- ai.html
- profile.html
- vehicle.html
- tacho.html
- offline.html
- i18n.js
- skin.css
- hero-road.jpg

Rebuilt Android shell:
- WebView host
- Internet permission
- GPS/location permission
- HTML geolocation support
- Native Android file picker for gallery/images
- No internal camera capture path
- Separate test package: com.trucklife.recovered
  This is intentional so the recovered test app can coexist with an existing Truck Life install.

Important:
- The HTML/JS/CSS assets are the recovered v1.20 application content.
- The Android Java shell is reconstructed because the original Java/Kotlin source for v1.20 was not present in the package.
- Before replacing the production package id, test this recovery build separately.
